/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;


/**
 *
 * @author antho
 */
public class ImagemClimaFavorab {
    private Integer id;
    private static int contadorId = 0;
    private String descFavorab; // desc_favorab (character varying)

    // Construtor padrão
    public ImagemClimaFavorab() {
    }
    
    public ImagemClimaFavorab(Integer id){
       this.id = id; 
    }
    
    // Construtor com parâmetros
    
    public ImagemClimaFavorab(Integer id, String descFavorab) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.descFavorab = descFavorab;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescFavorab() {
        return descFavorab;
    }

    public void setDescFavorab(String descFavorab) {
        this.descFavorab = descFavorab;
    }
    
    public void adicionarAoBancoImagens(int bancoId, ObjectContainer db) {
        BancoImagens exemploBanco = new BancoImagens();
        exemploBanco.setId(bancoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<BancoImagens> resultado = db.queryByExample(exemploBanco);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            BancoImagens projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarImagemClimaFavorabList(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + bancoId);
        } else {
            System.out.println("Projeto com ID " + bancoId + " não encontrado.");
        }
    }
    public void adicionarAoDadosClimaticos(int dadosCId, ObjectContainer db) {
        DadosClimaticos exemploDadosC = new DadosClimaticos();
        exemploDadosC.setId(dadosCId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<DadosClimaticos> resultado = db.queryByExample(exemploDadosC);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            DadosClimaticos projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarImagemClimaFavorab(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + dadosCId);
        } else {
            System.out.println("Projeto com ID " + dadosCId + " não encontrado.");
        }
    }
    public void adicionarAoDadosPlantaSoja(int dadosPId, ObjectContainer db) {
        DadosPlantaSoja exemploDadosP = new DadosPlantaSoja();
        exemploDadosP.setId(dadosPId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<DadosPlantaSoja> resultado = db.queryByExample(exemploDadosP);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            DadosPlantaSoja projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarImagemClimaFavorabList(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + dadosPId);
        } else {
            System.out.println("Projeto com ID " + dadosPId + " não encontrado.");
        }
    }
    
    public void adicionarAoTabVerdFavorabilidade(int tabVerId, ObjectContainer db) {
        TabVerdFavorabilidade exemploTabV = new TabVerdFavorabilidade();
        exemploTabV.setId(tabVerId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<TabVerdFavorabilidade> resultado = db.queryByExample(exemploTabV);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            TabVerdFavorabilidade projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarImagemClimaFavorab(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + tabVerId);
        } else {
            System.out.println("Projeto com ID " + tabVerId + " não encontrado.");
        }
    }

    @Override
    public String toString() {
        return "ImagemClimaFavorab{" + "id=" + id + ", descFavorab=" + descFavorab +'}';
    }

}
