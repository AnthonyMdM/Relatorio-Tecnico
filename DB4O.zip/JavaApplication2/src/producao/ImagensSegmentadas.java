/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author antho
 */
public class ImagensSegmentadas {
    private Integer id;
    private static int contadorId = 0;
    private byte[] imgSegmentReferencia; // img_segment_referencia (bytea)
    private byte[] imgFiltroMediana; // img_filtro_mediana (bytea)
    private byte[] imgCanalVerde; // img_canal_verde (bytea)
    private byte[] imgJanela; // img_janela (bytea)
    private byte[] imgLimiarizada; // img_limiarizada (bytea)
    private String classeCor; // classe_cor (character varying)
    private String descricaoImgOrigem; // descricao_img_origem (character varying)
    private byte[] imgRotuloEscolhido; // img_rotulo_escolhido (bytea)
    private double mse; // mse (double precision)
    private double psnr; // psnr (double precision)
    private double ssim; // ssim (double precision)
    private byte[] histograma; // histograma (bytea)
    private byte[] boxplotSementes; // boxplot_sementes (bytea)
    private byte[] boxplotSementesCalculo; // boxplot_sementes_calculo (bytea)
    private Integer outliersBoxplotSementes; // outliers_boxplot_sementes (integer, pode ser null)
    private Integer outliersBoxplotSementesCalculo; // outliers_boxplot_sementes_calculo (integer, pode ser null)
    private List<Segmentacao> segmentacaoList = new ArrayList<>();
    // Construtor padrão
    public ImagensSegmentadas() {
    }

    // Construtor com parâmetros
    public ImagensSegmentadas(Integer id,byte[] imgSegmentReferencia, byte[] imgFiltroMediana,
                            byte[] imgCanalVerde, byte[] imgJanela, byte[] imgLimiarizada, 
                            String classeCor, String descricaoImgOrigem, 
                            byte[] imgRotuloEscolhido, double mse, double psnr, double ssim,
                            byte[] histograma, byte[] boxplotSementes, byte[] boxplotSementesCalculo,
                            Integer outliersBoxplotSementes, Integer outliersBoxplotSementesCalculo) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.imgSegmentReferencia = imgSegmentReferencia;
        this.imgFiltroMediana = imgFiltroMediana;
        this.imgCanalVerde = imgCanalVerde;
        this.imgJanela = imgJanela;
        this.imgLimiarizada = imgLimiarizada;
        this.classeCor = classeCor;
        this.descricaoImgOrigem = descricaoImgOrigem;
        this.imgRotuloEscolhido = imgRotuloEscolhido;
        this.mse = mse;
        this.psnr = psnr;
        this.ssim = ssim;
        this.histograma = histograma;
        this.boxplotSementes = boxplotSementes;
        this.boxplotSementesCalculo = boxplotSementesCalculo;
        this.outliersBoxplotSementes = outliersBoxplotSementes;
        this.outliersBoxplotSementesCalculo = outliersBoxplotSementesCalculo;
    }
    
    public int getId() {
        return id;
    }

    // Getters e Setters para encapsulamento
    public void setId(Integer id) {    
        this.id = id;
    }

    public byte[] getImgSegmentReferencia() {
        return imgSegmentReferencia;
    }

    public void setImgSegmentReferencia(byte[] imgSegmentReferencia) {
        this.imgSegmentReferencia = imgSegmentReferencia;
    }

    public byte[] getImgFiltroMediana() {
        return imgFiltroMediana;
    }

    public void setImgFiltroMediana(byte[] imgFiltroMediana) {
        this.imgFiltroMediana = imgFiltroMediana;
    }

    public byte[] getImgCanalVerde() {
        return imgCanalVerde;
    }

    public void setImgCanalVerde(byte[] imgCanalVerde) {
        this.imgCanalVerde = imgCanalVerde;
    }

    public byte[] getImgJanela() {
        return imgJanela;
    }

    public void setImgJanela(byte[] imgJanela) {
        this.imgJanela = imgJanela;
    }

    public byte[] getImgLimiarizada() {
        return imgLimiarizada;
    }

    public void setImgLimiarizada(byte[] imgLimiarizada) {
        this.imgLimiarizada = imgLimiarizada;
    }

    public String getClasseCor() {
        return classeCor;
    }

    public void setClasseCor(String classeCor) {
        this.classeCor = classeCor;
    }

    public String getDescricaoImgOrigem() {
        return descricaoImgOrigem;
    }

    public void setDescricaoImgOrigem(String descricaoImgOrigem) {
        this.descricaoImgOrigem = descricaoImgOrigem;
    }

    public void getSegmentacao() {
    segmentacaoList.forEach(System.out::println);
    }

    public void adicionarSegmentacao(Segmentacao segmentacao) {
        segmentacaoList.add(segmentacao);
    }
    
    public List<Segmentacao> getSegmentacaoList() {
    return segmentacaoList;
}

    public byte[] getImgRotuloEscolhido() {
        return imgRotuloEscolhido;
    }

    public void setImgRotuloEscolhido(byte[] imgRotuloEscolhido) {
        this.imgRotuloEscolhido = imgRotuloEscolhido;
    }

    public double getMse() {
        return mse;
    }

    public void setMse(double mse) {
        this.mse = mse;
    }

    public double getPsnr() {
        return psnr;
    }

    public void setPsnr(double psnr) {
        this.psnr = psnr;
    }

    public double getSsim() {
        return ssim;
    }

    public void setSsim(double ssim) {
        this.ssim = ssim;
    }

    public byte[] getHistograma() {
        return histograma;
    }

    public void setHistograma(byte[] histograma) {
        this.histograma = histograma;
    }

    public byte[] getBoxplotSementes() {
        return boxplotSementes;
    }

    public void setBoxplotSementes(byte[] boxplotSementes) {
        this.boxplotSementes = boxplotSementes;
    }

    public byte[] getBoxplotSementesCalculo() {
        return boxplotSementesCalculo;
    }

    public void setBoxplotSementesCalculo(byte[] boxplotSementesCalculo) {
        this.boxplotSementesCalculo = boxplotSementesCalculo;
    }

    public Integer getOutliersBoxplotSementes() {
        return outliersBoxplotSementes;
    }

    public void setOutliersBoxplotSementes(Integer outliersBoxplotSementes) {
        this.outliersBoxplotSementes = outliersBoxplotSementes;
    }

    public Integer getOutliersBoxplotSementesCalculo() {
        return outliersBoxplotSementesCalculo;
    }

    public void setOutliersBoxplotSementesCalculo(Integer outliersBoxplotSementesCalculo) {
        this.outliersBoxplotSementesCalculo = outliersBoxplotSementesCalculo;
    }

    public void adicionarAoBancoImagens(int bancoId, ObjectContainer db) {
        BancoImagens exemploBanco = new BancoImagens();
        exemploBanco.setId(bancoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<BancoImagens> resultado = db.queryByExample(exemploBanco);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            BancoImagens projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarImagensSegmentadasList(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + bancoId);
        } else {
            System.out.println("Projeto com ID " + bancoId + " não encontrado.");
        }
    }
    @Override
    public String toString() {
        return "ImagensSegmentadas{" + "id=" + id + ", imgSegmentReferencia=" + imgSegmentReferencia + ", imgFiltroMediana=" + imgFiltroMediana + ", imgCanalVerde=" + imgCanalVerde + ", imgJanela=" + imgJanela + ", imgLimiarizada=" + imgLimiarizada + ", classeCor=" + classeCor + ", descricaoImgOrigem=" + descricaoImgOrigem + ", imgRotuloEscolhido=" + imgRotuloEscolhido + ", mse=" + mse + ", psnr=" + psnr + ", ssim=" + ssim + ", histograma=" + histograma + ", boxplotSementes=" + boxplotSementes + ", boxplotSementesCalculo=" + boxplotSementesCalculo + ", outliersBoxplotSementes=" + outliersBoxplotSementes + ", outliersBoxplotSementesCalculo=" + outliersBoxplotSementesCalculo + ", segmentacaoList=" + segmentacaoList + '}';
    }

}
