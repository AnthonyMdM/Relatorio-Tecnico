/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;
import java.util.ArrayList;
import java.util.List;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
/**
 *
 * @author antho
 */
public class BancoImagens{
    private Integer id;
    private static int contadorId = 0; 
    private String descricaoImgOriginal; // descricao_img_original (character varying)
    private byte[] imgOriginal; // img_original (bytea)
    private int alturaImgOriginal; // altura_img_original (integer)
    private int larguraImgOriginal; // largura_img_original (integer)
    private int numCanaisImgOriginal; // num_canais_img_original (integer)
    private int totalPixelsImgOriginal; // total_pixels_img_original (integer)
    private String tipoImgOriginal; 
    private List<Classificacoes> classificacoesList = new ArrayList<>();
    private List<FavorabilidadesFas> favorabilidadesFasList = new ArrayList<>();
    private List<ImagemClimaFavorab> imagemClimaFavorabList = new ArrayList<>();
    private List<ImagensSegmentadas> imagensSegmentadasList = new ArrayList<>();

    public BancoImagens(Integer id, String descricaoImgOriginal, byte[] imgOriginal, int alturaImgOriginal, int larguraImgOriginal, int numCanaisImgOriginal, int totalPixelsImgOriginal, String tipoImgOriginal) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.descricaoImgOriginal = descricaoImgOriginal;
        this.imgOriginal = imgOriginal;
        this.alturaImgOriginal = alturaImgOriginal;
        this.larguraImgOriginal = larguraImgOriginal;
        this.numCanaisImgOriginal = numCanaisImgOriginal;
        this.totalPixelsImgOriginal = totalPixelsImgOriginal;
        this.tipoImgOriginal = tipoImgOriginal;
    }

    BancoImagens(){}

    public String getDescricaoImgOriginal() {
        return descricaoImgOriginal;
    }

    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

      
    public void setDescricaoImgOriginal(String descricaoImgOriginal) {
        this.descricaoImgOriginal = descricaoImgOriginal;
    }

    public byte[] getImgOriginal() {
        return imgOriginal;
    }

    public void setImgOriginal(byte[] imgOriginal) {
        this.imgOriginal = imgOriginal;
    }

    public int getAlturaImgOriginal() {
        return alturaImgOriginal;
    }

    public void setAlturaImgOriginal(int alturaImgOriginal) {
        this.alturaImgOriginal = alturaImgOriginal;
    }

    public int getLarguraImgOriginal() {
        return larguraImgOriginal;
    }

    public void setLarguraImgOriginal(int larguraImgOriginal) {
        this.larguraImgOriginal = larguraImgOriginal;
    }

    public int getNumCanaisImgOriginal() {
        return numCanaisImgOriginal;
    }

    public void setNumCanaisImgOriginal(int numCanaisImgOriginal) {
        this.numCanaisImgOriginal = numCanaisImgOriginal;
    }

    public int getTotalPixelsImgOriginal() {
        return totalPixelsImgOriginal;
    }

    public void setTotalPixelsImgOriginal(int totalPixelsImgOriginal) {
        this.totalPixelsImgOriginal = totalPixelsImgOriginal;
    }

    public String getTipoImgOriginal() {
        return tipoImgOriginal;
    }

    public void setTipoImgOriginal(String tipoImgOriginal) {
        this.tipoImgOriginal = tipoImgOriginal;
    }
    
    public void adicionarClassificacoes(Classificacoes classificacoes) {
        classificacoesList.add(classificacoes);
    }
    
    public void getClassificacoes() {
        classificacoesList.forEach(System.out::println);
    }
    
    public List<Classificacoes> getClassificacoesList() {
    return classificacoesList;
    }
    
    public void adicionarFavorabilidadesFas(FavorabilidadesFas favorabilidades) {
        favorabilidadesFasList.add(favorabilidades);
    }
    
    public void getFavorabilidadesFas() {
        favorabilidadesFasList.forEach(System.out::println);
    }
    
    public List<FavorabilidadesFas> getFavorabilidadesFasList() {
    return favorabilidadesFasList;
    }
    
    public void adicionarImagemClimaFavorabList(ImagemClimaFavorab imagemClima) {
        imagemClimaFavorabList.add(imagemClima);
    }
    
    public void getImagemClimaFavorab() {
        imagemClimaFavorabList.forEach(System.out::println);
    }
    
    public List<ImagemClimaFavorab> getImagemClimaFavorabList() {
    return imagemClimaFavorabList;
    }
    
    public void adicionarImagensSegmentadasList(ImagensSegmentadas imagensSeg) {
        imagensSegmentadasList.add(imagensSeg);
    }
    
    public void getImagensSegmentadas() {
    imagensSegmentadasList.forEach(System.out::println);
    }

    public List<ImagensSegmentadas> getImagensSegmentadasList() {
    return imagensSegmentadasList;
    }
    
    public void adicionarAoProjeto(int projetoId, ObjectContainer db) {
        Projetos exemploProjeto = new Projetos();
        exemploProjeto.setId(projetoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Projetos> resultado = db.queryByExample(exemploProjeto);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Projetos projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarBancoImagens(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + projetoId);
        } else {
            System.out.println("Projeto com ID " + projetoId + " não encontrado.");
        }
    }

    @Override
    public String toString() {
        return "BancoImagens{" + "id=" + id + ", descricaoImgOriginal=" + descricaoImgOriginal + ", imgOriginal=" + imgOriginal + ", alturaImgOriginal=" + alturaImgOriginal + ", larguraImgOriginal=" + larguraImgOriginal + ", numCanaisImgOriginal=" + numCanaisImgOriginal + ", totalPixelsImgOriginal=" + totalPixelsImgOriginal + ", tipoImgOriginal=" + tipoImgOriginal + ", classificacoesList=" + classificacoesList + ", favorabilidadesFasList=" + favorabilidadesFasList + ", imagemClimaFavorabList=" + imagemClimaFavorabList + ", imagensSegmentadasList=" + imagensSegmentadasList + "}";
    }
    
}
