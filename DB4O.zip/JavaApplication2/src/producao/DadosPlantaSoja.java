/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author antho
 */
public class DadosPlantaSoja {

    private Integer id;
    private static int contadorId = 0;
    private String variedadeCultura; // variedade_cultura (character varying)
    private double distanciaLinhaCultura; // distancia_linha_cultura (double precision)
    private double alturaPlantaCultura; // altura_planta_cultura (double precision)
    private double distanciaPlantaCultura; // distancia_planta_cultura (double precision)
    private Integer plantasMetroLinear; // plantas_metro_linear (integer, pode ser null)
    private String status; // status (character varying)
    private List<ImagemClimaFavorab> imagemClimaFavorabList = new ArrayList<>();

    // Construtor padrão
    public DadosPlantaSoja() {

    }

    // Construtor com parâmetros
    public DadosPlantaSoja(Integer id, String variedadeCultura, double distanciaLinhaCultura, double alturaPlantaCultura, double distanciaPlantaCultura, Integer plantasMetroLinear, String status) {
        if (id == null) {
            this.id = ++contadorId; // Gera um novo ID automaticamente
        } else {
            this.id = id;
        }
        this.variedadeCultura = variedadeCultura;
        this.distanciaLinhaCultura = distanciaLinhaCultura;
        this.alturaPlantaCultura = alturaPlantaCultura;
        this.distanciaPlantaCultura = distanciaPlantaCultura;
        this.plantasMetroLinear = plantasMetroLinear;
        this.status = status;
    }

    public void getImagemClimaFavorab() {
        imagemClimaFavorabList.forEach(System.out::println);
    }

    public void adicionarImagemClimaFavorabList(ImagemClimaFavorab imagemClimaFav) {
        imagemClimaFavorabList.add(imagemClimaFav);
    }

    public List<ImagemClimaFavorab> getImagemClimaFavorabList() {
        return imagemClimaFavorabList;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVariedadeCultura() {
        return variedadeCultura;
    }

    public void setVariedadeCultura(String variedadeCultura) {
        this.variedadeCultura = variedadeCultura;
    }

    public double getDistanciaLinhaCultura() {
        return distanciaLinhaCultura;
    }

    public void setDistanciaLinhaCultura(double distanciaLinhaCultura) {
        this.distanciaLinhaCultura = distanciaLinhaCultura;
    }

    public double getAlturaPlantaCultura() {
        return alturaPlantaCultura;
    }

    public void setAlturaPlantaCultura(double alturaPlantaCultura) {
        this.alturaPlantaCultura = alturaPlantaCultura;
    }

    public double getDistanciaPlantaCultura() {
        return distanciaPlantaCultura;
    }

    public void setDistanciaPlantaCultura(double distanciaPlantaCultura) {
        this.distanciaPlantaCultura = distanciaPlantaCultura;
    }

    public Integer getPlantasMetroLinear() {
        return plantasMetroLinear;
    }

    public void setPlantasMetroLinear(Integer plantasMetroLinear) {
        this.plantasMetroLinear = plantasMetroLinear;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void adicionarAoProjeto(int projetoId, ObjectContainer db) {
        Projetos exemploProjeto = new Projetos();
        exemploProjeto.setId(projetoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Projetos> resultado = db.queryByExample(exemploProjeto);

        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Projetos projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarDadosPlantaSoja(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O

            System.out.println("BancoImagens adicionado ao Projeto com ID: " + projetoId);
        } else {
            System.out.println("Projeto com ID " + projetoId + " não encontrado.");
        }
    }

    @Override
    public String toString() {
        return "DadosPlantaSoja{" + "id=" + id + ", variedadeCultura=" + variedadeCultura + ", distanciaLinhaCultura=" + distanciaLinhaCultura + ", alturaPlantaCultura=" + alturaPlantaCultura + ", distanciaPlantaCultura=" + distanciaPlantaCultura + ", plantasMetroLinear=" + plantasMetroLinear + ", status=" + status + ", imagemClimaFavorabList=" + imagemClimaFavorabList + '}';
    }

}
