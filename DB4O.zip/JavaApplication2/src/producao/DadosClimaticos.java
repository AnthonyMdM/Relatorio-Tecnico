/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author antho
 */
public class DadosClimaticos {
    private Integer id;
    private static int contadorId = 0; 
    private String localEstacaoClimatica; // local_estacao_climatica (character varying)
    private String periodoMedicao; // periodo_medicao (character varying)
    private LocalDate dataMedicao; // data_medicao (date)
    private double precipitacao; // precipitacao (double precision)
    private double temperaturaMax; // temperatura_max (double precision)
    private double temperaturaMin; // temperatura_min (double precision)
    private double umidadeRelativa; // umidade_relativa (double precision)
    private double pontoOrvalho; // ponto_orvalho (double precision)
    private double temperaturaMedCompensada; // temperatura_med_compensada (double precision)
    private String regiaoEstacaoClimatica; // regiao_estacao_climatica (character varying)
    private String status; // status (character varying)
    private List<ImagemClimaFavorab> imagemClimaFavorabList = new ArrayList<>();
    // Construtor padrão
    public DadosClimaticos() {
    }
    
    public DadosClimaticos(Integer id){
       this.id = id; 
    }
    
    // Construtor com parâmetros
    public DadosClimaticos( Integer id, String localEstacaoClimatica, String periodoMedicao,
                           LocalDate dataMedicao, double precipitacao, double temperaturaMax, double temperaturaMin,
                           double umidadeRelativa, double pontoOrvalho, double temperaturaMedCompensada,
                           String regiaoEstacaoClimatica, String status) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.localEstacaoClimatica = localEstacaoClimatica;
        this.periodoMedicao = periodoMedicao;
        this.dataMedicao = dataMedicao;
        this.precipitacao = precipitacao;
        this.temperaturaMax = temperaturaMax;
        this.temperaturaMin = temperaturaMin;
        this.umidadeRelativa = umidadeRelativa;
        this.pontoOrvalho = pontoOrvalho;
        this.temperaturaMedCompensada = temperaturaMedCompensada;
        this.regiaoEstacaoClimatica = regiaoEstacaoClimatica;
        this.status = status;
    }

    // Getters e Setters para encapsulamento
    public void adicionarImagemClimaFavorab(ImagemClimaFavorab favorabilidades) {
        imagemClimaFavorabList.add(favorabilidades);
    }
    
    public void getimagemClimaFavorab() {
        imagemClimaFavorabList.forEach(System.out::println);
    }
    
    
    public List<ImagemClimaFavorab> getImagemClimaFavorabList() {
        return imagemClimaFavorabList;
    }

    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getLocalEstacaoClimatica() {
        return localEstacaoClimatica;
    }

    public void setLocalEstacaoClimatica(String localEstacaoClimatica) {
        this.localEstacaoClimatica = localEstacaoClimatica;
    }

    public String getPeriodoMedicao() {
        return periodoMedicao;
    }

    public void setPeriodoMedicao(String periodoMedicao) {
        this.periodoMedicao = periodoMedicao;
    }

    public LocalDate getDataMedicao() {
        return dataMedicao;
    }

    public void setDataMedicao(LocalDate dataMedicao) {
        this.dataMedicao = dataMedicao;
    }

    public double getPrecipitacao() {
        return precipitacao;
    }

    public void setPrecipitacao(double precipitacao) {
        this.precipitacao = precipitacao;
    }

    public double getTemperaturaMax() {
        return temperaturaMax;
    }

    public void setTemperaturaMax(double temperaturaMax) {
        this.temperaturaMax = temperaturaMax;
    }

    public double getTemperaturaMin() {
        return temperaturaMin;
    }

    public void setTemperaturaMin(double temperaturaMin) {
        this.temperaturaMin = temperaturaMin;
    }

    public double getUmidadeRelativa() {
        return umidadeRelativa;
    }

    public void setUmidadeRelativa(double umidadeRelativa) {
        this.umidadeRelativa = umidadeRelativa;
    }

    public double getPontoOrvalho() {
        return pontoOrvalho;
    }

    public void setPontoOrvalho(double pontoOrvalho) {
        this.pontoOrvalho = pontoOrvalho;
    }

    public double getTemperaturaMedCompensada() {
        return temperaturaMedCompensada;
    }

    public void setTemperaturaMedCompensada(double temperaturaMedCompensada) {
        this.temperaturaMedCompensada = temperaturaMedCompensada;
    }

    public String getRegiaoEstacaoClimatica() {
        return regiaoEstacaoClimatica;
    }

    public void setRegiaoEstacaoClimatica(String regiaoEstacaoClimatica) {
        this.regiaoEstacaoClimatica = regiaoEstacaoClimatica;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public void adicionarAoProjeto(int projetoId, ObjectContainer db) {
        Projetos exemploProjeto = new Projetos();
        exemploProjeto.setId(projetoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Projetos> resultado = db.queryByExample(exemploProjeto);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Projetos projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarDadosClimaticos(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + projetoId);
        } else {
            System.out.println("Projeto com ID " + projetoId + " não encontrado.");
        }
    }

    @Override
    public String toString() {
        return "DadosClimaticos{" + "id=" + id + ", localEstacaoClimatica=" + localEstacaoClimatica + ", periodoMedicao=" + periodoMedicao + ", dataMedicao=" + dataMedicao + ", precipitacao=" + precipitacao + ", temperaturaMax=" + temperaturaMax + ", temperaturaMin=" + temperaturaMin + ", umidadeRelativa=" + umidadeRelativa + ", pontoOrvalho=" + pontoOrvalho + ", temperaturaMedCompensada=" + temperaturaMedCompensada + ", regiaoEstacaoClimatica=" + regiaoEstacaoClimatica + ", status=" + status + ", imagemClimaFavorabList=" + imagemClimaFavorabList + '}';
    }
    
}
