/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;

/**
 *
 * @author antho
 */
public class RecomendacoesFungicidas {
    // Atributos privados da classe
    private Integer id;
    private static int contadorId = 0; 
    int fungicidasId;

    public int getFungicidasId() {
        return fungicidasId;
    }

    public void setFungicidasId(int fungicidasId) {
        this.fungicidasId = fungicidasId;
    }

    public int getRecomendacoesId() {
        return recomendacoesId;
    }

    public void setRecomendacoesId(int recomendacoesId) {
        this.recomendacoesId = recomendacoesId;
    }
    int recomendacoesId;
    // Construtor padrão
    public RecomendacoesFungicidas() {
    }

    // Getters e Setters para encapsulamento

    public RecomendacoesFungicidas(Integer id, int fungicidasId, int recomendacoesId) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.fungicidasId = fungicidasId;
        this.recomendacoesId = recomendacoesId;
    }



    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void adicionarAoFungicidas(int fungicidasId, ObjectContainer db) {
        Fungicidas exemploFungicidas = new Fungicidas();
        exemploFungicidas.setId(fungicidasId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Fungicidas> resultado = db.queryByExample(exemploFungicidas);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Fungicidas projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarRecomendacoesFungicidas(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + fungicidasId);
        } else {
            System.out.println("Projeto com ID " + fungicidasId + " não encontrado.");
        }
    }
    public void adicionarAsRecomendacoes(int recomendacoesId, ObjectContainer db) {
        Recomendacoes exemploRecomendacoes = new Recomendacoes();
        exemploRecomendacoes.setId(recomendacoesId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Recomendacoes> resultado = db.queryByExample(exemploRecomendacoes);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Recomendacoes projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarRecomendacoesFungicidas(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + recomendacoesId);
        } else {
            System.out.println("Projeto com ID " + recomendacoesId + " não encontrado.");
        }
    }

    @Override
    public String toString() {
        return "RecomendacoesFungicidas{" + "id=" + id + '}';
    }

}
