/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author antho
 */
public class TabVerdFavorabilidade {
    private static int contadorId = 0;
    private Integer id;
    private int v1; // v1 (integer)
    private int v2; // v2 (integer)
    private int v3; // v3 (integer)
    private int v4; // v4 (integer)
    private int v5; // v5 (integer)
    private int v6; // v6 (integer)
    private int v7; // v7 (integer)
    private int s; // s (integer)
    private double pV1; // p_v1 (double precision)
    private double pV2; // p_v2 (double precision)
    private double pV3; // p_v3 (double precision)
    private double pV4; // p_v4 (double precision)
    private double pV5; // p_v5 (double precision)
    private double pV6; // p_v6 (double precision)
    private double pV7; // p_v7 (double precision)
    private List<ImagemClimaFavorab> imagemClimaFavorabList = new ArrayList<>();
    // Construtor padrão
    public TabVerdFavorabilidade() {
    }

    // Construtor com parâmetros
    public TabVerdFavorabilidade(Integer id, int v1, int v2, int v3, int v4, int v5, int v6, int v7, int s,
                                 double pV1, double pV2, double pV3, double pV4, double pV5, double pV6, double pV7) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
        this.v4 = v4;
        this.v5 = v5;
        this.v6 = v6;
        this.v7 = v7;
        this.s = s;
        this.pV1 = pV1;
        this.pV2 = pV2;
        this.pV3 = pV3;
        this.pV4 = pV4;
        this.pV5 = pV5;
        this.pV6 = pV6;
        this.pV7 = pV7;
    }

    public void adicionarImagemClimaFavorab(ImagemClimaFavorab favorabilidades) {
        imagemClimaFavorabList.add(favorabilidades);
    }
    
    public void getimagemClimaFavorab() {
        imagemClimaFavorabList.forEach(System.out::println);
    }
    
    public List<ImagemClimaFavorab> getImagemClimaFavorabList() {
    return imagemClimaFavorabList;
    }
    
    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public int getV1() {
        return v1;
    }

    public void setV1(int v1) {
        this.v1 = v1;
    }

    public int getV2() {
        return v2;
    }

    public void setV2(int v2) {
        this.v2 = v2;
    }

    public int getV3() {
        return v3;
    }

    public void setV3(int v3) {
        this.v3 = v3;
    }

    public int getV4() {
        return v4;
    }

    public void setV4(int v4) {
        this.v4 = v4;
    }

    public int getV5() {
        return v5;
    }

    public void setV5(int v5) {
        this.v5 = v5;
    }

    public int getV6() {
        return v6;
    }

    public void setV6(int v6) {
        this.v6 = v6;
    }

    public int getV7() {
        return v7;
    }

    public void setV7(int v7) {
        this.v7 = v7;
    }

    public int getS() {
        return s;
    }

    public void setS(int s) {
        this.s = s;
    }

    public double getpV1() {
        return pV1;
    }

    public void setpV1(double pV1) {
        this.pV1 = pV1;
    }

    public double getpV2() {
        return pV2;
    }

    public void setpV2(double pV2) {
        this.pV2 = pV2;
    }

    public double getpV3() {
        return pV3;
    }

    public void setpV3(double pV3) {
        this.pV3 = pV3;
    }

    public double getpV4() {
        return pV4;
    }

    public void setpV4(double pV4) {
        this.pV4 = pV4;
    }

    public double getpV5() {
        return pV5;
    }

    public void setpV5(double pV5) {
        this.pV5 = pV5;
    }

    public double getpV6() {
        return pV6;
    }

    public void setpV6(double pV6) {
        this.pV6 = pV6;
    }

    public double getpV7() {
        return pV7;
    }

    public void setpV7(double pV7) {
        this.pV7 = pV7;
    }

    @Override
    public String toString() {
        return "TabVerdFavorabilidade{" + "id=" + id + ", v1=" + v1 + ", v2=" + v2 + ", v3=" + v3 + ", v4=" + v4 + ", v5=" + v5 + ", v6=" + v6 + ", v7=" + v7 + ", s=" + s + ", pV1=" + pV1 + ", pV2=" + pV2 + ", pV3=" + pV3 + ", pV4=" + pV4 + ", pV5=" + pV5 + ", pV6=" + pV6 + ", pV7=" + pV7 + ", imagemClimaFavorabList=" + imagemClimaFavorabList + '}';
    }
    
    
}
