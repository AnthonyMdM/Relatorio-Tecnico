/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
/**
 *
 * @author antho
 */
public class Classificacoes {
    private Integer id;
    private static int contadorId = 0; 
    private int resultado;
    private Integer porcentagemTreino; // porcentagem_treino (integer, pode ser null)
    private Integer porcentagemTeste; // porcentagem_teste (integer, pode ser null)
    private String tipoClassificacao; // tipo_classificacao (character varying)
    private String relatorioClassificacao; // relatorio_classificacao (text)
    private byte[] matrizConfusao; // matriz_confusao (bytea)
    private byte[] curvaRoc; // curva_roc (bytea)
    private Integer tuplasBinarias; // tuplas_binarias (integer)
    private Integer tuplasBinariasLimpas; // tuplas_binarias_limpas (integer)
    private double percTuplasDuplElimin; // perc_tuplas_dupl_elimin (double precision)    

    // Construtor padrão
    public Classificacoes() {
    }
    
    public Classificacoes(Integer id){
       this.id = id; 
    }
    
    // Construtor com parâmetros
    public Classificacoes(Integer id, int resultado, Integer porcentagemTreino, 
                         Integer porcentagemTeste, String tipoClassificacao, String relatorioClassificacao, byte[] matrizConfusao, 
                         byte[] curvaRoc, int tuplasBinarias, int tuplasBinariasLimpas, double percTuplasDuplElimin) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.resultado = resultado;
        this.porcentagemTreino = porcentagemTreino;
        this.porcentagemTeste = porcentagemTeste;
        this.tipoClassificacao = tipoClassificacao;
        this.relatorioClassificacao = relatorioClassificacao;
        this.matrizConfusao = matrizConfusao;
        this.curvaRoc = curvaRoc;
        this.tuplasBinarias = tuplasBinarias;
        this.tuplasBinariasLimpas = tuplasBinariasLimpas;
        this.percTuplasDuplElimin = percTuplasDuplElimin;
    }

    // Getters e Setters para encapsulamento

    public Integer getPorcentagemTreino() {
        return porcentagemTreino;
    }

    public void setPorcentagemTreino(Integer porcentagemTreino) {
        this.porcentagemTreino = porcentagemTreino;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }

    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getPorcentagemTeste() {
        return porcentagemTeste;
    }

    public void setPorcentagemTeste(Integer porcentagemTeste) {
        this.porcentagemTeste = porcentagemTeste;
    }

    public String getTipoClassificacao() {
        return tipoClassificacao;
    }

    public void setTipoClassificacao(String tipoClassificacao) {
        this.tipoClassificacao = tipoClassificacao;
    }

    public String getRelatorioClassificacao() {
        return relatorioClassificacao;
    }

    public void setRelatorioClassificacao(String relatorioClassificacao) {
        this.relatorioClassificacao = relatorioClassificacao;
    }

    public byte[] getMatrizConfusao() {
        return matrizConfusao;
    }

    public void setMatrizConfusao(byte[] matrizConfusao) {
        this.matrizConfusao = matrizConfusao;
    }

    public byte[] getCurvaRoc() {
        return curvaRoc;
    }

    public void setCurvaRoc(byte[] curvaRoc) {
        this.curvaRoc = curvaRoc;
    }

    public Integer getTuplasBinarias() {
        return tuplasBinarias;
    }

    public void setTuplasBinarias(int tuplasBinarias) {
        this.tuplasBinarias = tuplasBinarias;
    }

    public Integer getTuplasBinariasLimpas() {
        return tuplasBinariasLimpas;
    }

    public void setTuplasBinariasLimpas(int tuplasBinariasLimpas) {
        this.tuplasBinariasLimpas = tuplasBinariasLimpas;
    }

    public double getPercTuplasDuplElimin() {
        return percTuplasDuplElimin;
    }

    public void setPercTuplasDuplElimin(double percTuplasDuplElimin) {
        this.percTuplasDuplElimin = percTuplasDuplElimin;
    }
     public void adicionarAoProjeto(int projetoId, ObjectContainer db) {
        Projetos exemploProjeto = new Projetos();
        exemploProjeto.setId(projetoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Projetos> resultado = db.queryByExample(exemploProjeto);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Projetos projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarClassificacoes(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + projetoId);
        } else {
            System.out.println("Projeto com ID " + projetoId + " não encontrado.");
        }
    }
     
    public void adicionarAoBancoImagens(int bancoId, ObjectContainer db) {
        BancoImagens exemploBanco = new BancoImagens();
        exemploBanco.setId(bancoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<BancoImagens> resultado = db.queryByExample(exemploBanco);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            BancoImagens projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarClassificacoes(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + bancoId);
        } else {
            System.out.println("Projeto com ID " + bancoId + " não encontrado.");
        }
    }

    @Override
    public String toString() {
        return "Classificacoes{" + "id=" + id + ", porcentagemTreino=" + porcentagemTreino + ", porcentagemTeste=" + porcentagemTeste + ", tipoClassificacao=" + tipoClassificacao + ", relatorioClassificacao=" + relatorioClassificacao + ", matrizConfusao=" + matrizConfusao + ", curvaRoc=" + curvaRoc + ", tuplasBinarias=" + tuplasBinarias + ", tuplasBinariasLimpas=" + tuplasBinariasLimpas + ", percTuplasDuplElimin=" + percTuplasDuplElimin + '}';
    }

}
