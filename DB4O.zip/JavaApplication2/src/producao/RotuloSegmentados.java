/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;

/**
 *
 * @author antho
 */
public class RotuloSegmentados {
    private Integer id;
    private static int contadorId = 0; 
    private byte[] imgRotuloSegmentado;
    private String classeCor;

    // Construtor padrão
    public RotuloSegmentados() {
    }

    // Construtor com parâmetros
    public RotuloSegmentados(Integer id, byte[] imgRotuloSegmentado, String classeCor) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.imgRotuloSegmentado = imgRotuloSegmentado;
        this.classeCor = classeCor;
    }
    
    // Getters e Setters para encapsulamento
    public int getId() {
        return id;
    }
    
    public void setId(Integer id) {    
        this.id = id;
    }

    public byte[] getImgRotuloSegmentado() {
        return imgRotuloSegmentado;
    }

    public void setImgRotuloSegmentado(byte[] imgRotuloSegmentado) {
        this.imgRotuloSegmentado = imgRotuloSegmentado;
    }

    public String getClasseCor() {
        return classeCor;
    }

    public void setClasseCor(String classeCor) {
        this.classeCor = classeCor;
    }
    public void adicionarAoSegmentacao(int segmentacaoId, ObjectContainer db) {
        Segmentacao exemploSegmentacao = new Segmentacao();
        exemploSegmentacao.setId(segmentacaoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Segmentacao> resultado = db.queryByExample(exemploSegmentacao);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Segmentacao projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarRotuloSegmentados(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + segmentacaoId);
        } else {
            System.out.println("Projeto com ID " + segmentacaoId + " não encontrado.");
        }
    }

    @Override
    public String toString() {
        return "RotuloSegmentados{" + "id=" + id + ", imgRotuloSegmentado=" + imgRotuloSegmentado + ", classeCor=" + classeCor + '}';
    }

}
