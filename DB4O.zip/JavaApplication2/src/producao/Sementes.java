/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author antho
 */
public class Sementes {
    private static int contadorId = 0;
    private Integer id;
    private String descricaoCorSemente;
    private String corRgbSemente;
    private String dadosSementes;
    private List<Segmentacao> segmentacaoList = new ArrayList<>();

    // Construtor padrão
    public Sementes() {}

    public Sementes(Integer id, String descricaoCorSemente, String corRgbSemente, String dadosSementes) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.descricaoCorSemente = descricaoCorSemente;
        this.corRgbSemente = corRgbSemente;
        this.dadosSementes = dadosSementes;
    }

    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
   
    public String getDescricaoCorSemente() {
        return descricaoCorSemente;
    }

    public void setDescricaoCorSemente(String descricaoCorSemente) {
        this.descricaoCorSemente = descricaoCorSemente;
    }

    public String getCorRgbSemente() {
        return corRgbSemente;
    }

    public void setCorRgbSemente(String corRgbSemente) {
        this.corRgbSemente = corRgbSemente;
    }

    public String getDadosSementes() {
        return dadosSementes;
    }

    public void setDadosSementes(String dadosSementes) {
        this.dadosSementes = dadosSementes;
    } 
    
    public void adicionarSegmentacao(Segmentacao segmentacao) {
        segmentacaoList.add(segmentacao);
    }
    
    public void getSegmentacao() {
        segmentacaoList.forEach(System.out::println);
    }
    
    public List<Segmentacao> getSegmentacaoList() {
    return segmentacaoList;
    }

    @Override
    public String toString() {
        return "Sementes{" + "id=" + id + ", descricaoCorSemente=" + descricaoCorSemente + ", corRgbSemente=" + corRgbSemente + ", dadosSementes=" + dadosSementes + ", segmentacaoList=" + segmentacaoList + '}';
    }


}