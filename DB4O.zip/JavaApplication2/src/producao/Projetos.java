/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author antho
 */
public class Projetos {
    private static int contadorId = 0; 
    private Integer id;
    private String nomeProjeto;
    private String tipoProjeto;
    private List<BancoImagens> bancoImagensList = new ArrayList<>();
    private List<Classificacoes> classificacoesList = new ArrayList<>();
    private List<DadosClimaticos> dadosClimaticosList = new ArrayList<>();
    private List<DadosPlantaSoja> dadosPlantaSojaList = new ArrayList<>();
    private List<Segmentacao> segmentacaoList = new ArrayList<>();


    // Construtor padrão
    public Projetos() {
    }
    
    public Projetos(Integer id, String nomeProjeto, String tipoProjeto) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.nomeProjeto = nomeProjeto;
        this.tipoProjeto = tipoProjeto;
    }


    // Getters e Setters para encapsulamento
    
    public void adicionarBancoImagens(BancoImagens idBancoImagem) {
        bancoImagensList.add(idBancoImagem);
    }
    
    public void getBancoImagens() {
        bancoImagensList.forEach(System.out::println);
    }
    
    public List<BancoImagens> getBancoImagensList() {
    return bancoImagensList;
    }
    
    public void adicionarDadosClimaticos(DadosClimaticos dadosClima) {
        dadosClimaticosList.add(dadosClima);
    }
    
    public void getDadosClimaticos() {
        dadosClimaticosList.forEach(System.out::println);
    }
    
    public List<DadosClimaticos> getDadosClimaticosList() {
    return dadosClimaticosList;
    }
    
    public void adicionarDadosPlantaSoja(DadosPlantaSoja dadosSoja) {
        dadosPlantaSojaList.add(dadosSoja);
    }
    
    public void getDadosPlantaSoja() {
        dadosPlantaSojaList.forEach(System.out::println);
    }
    
    public List<DadosPlantaSoja> getDadosPlantaSojaList() {
    return dadosPlantaSojaList;
    }
    
    public void adicionarSegmentacao(Segmentacao segmentacao) {
        segmentacaoList.add(segmentacao);
    }
    
    public void getSegmentacao() {
        segmentacaoList.forEach(System.out::println);
    }
    
    public List<Segmentacao> getSegmentacaoList() {
    return segmentacaoList;
    }
    
    public void adicionarClassificacoes(Classificacoes classificacoes) {
        classificacoesList.add(classificacoes);
    }
    
    public void getClassificacoes() {
        classificacoesList.forEach(System.out::println);
    }

    public List<Classificacoes> getClassificacoesList() {
    return classificacoesList;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }


    public String getNomeProjeto() {
        return nomeProjeto;
    }

    public void setNomeProjeto(String nomeProjeto) {
        this.nomeProjeto = nomeProjeto;
    }

    public String getTipoProjeto() {
        return tipoProjeto;
    }

    public void setTipoProjeto(String tipoProjeto) {
        this.tipoProjeto = tipoProjeto;
    }

    @Override
    public String toString() {
        //return "Projetos{" + "id=" + id + ", nomeProjeto=" + nomeProjeto + ", tipoProjeto=" + tipoProjeto + ", bancoImagensList=" + bancoImagensList + ", classificacoesList=" + classificacoesList + ", dadosClimaticosList=" + dadosClimaticosList + ", dadosPlantaSojaList=" + dadosPlantaSojaList + ", segmentacaoList=" + segmentacaoList + '}';
        return "Projetos{" + "id=" + id + ", nomeProjeto=" + nomeProjeto + ", tipoProjeto=" + tipoProjeto + '}';
    }

}
