package producao;

import com.db4o.*;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.query.Query;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class NewClass {

    public static void main(String[] args) throws IOException {
        ObjectContainer db = configureAndOpenDb("pro.db4o"); //abertura/criação do Banco de Dados
        String[] filePaths = {
            "C:/Users/antho/Downloads/esfdt/Proj.csv",
            "C:/Users/antho/Downloads/esfdt/Recom.csv",
            "C:/Users/antho/Downloads/esfdt/Fung.csv",
            "C:/Users/antho/Downloads/esfdt/Tab.csv",
            "C:/Users/antho/Downloads/esfdt/Seme.csv",
            "C:/Users/antho/Downloads/esfdt/Banco_img.csv",
            "C:/Users/antho/Downloads/esfdt/Recom_Fug.csv",
            "C:\\Users\\antho\\Downloads\\esfdt\\Dados_Clima.csv",
            "C:/Users/antho/Downloads/esfdt/Dado_Soja.csv",
            "C:/Users/antho/Downloads/esfdt/Classificacoes.csv",
            "C:/Users/antho/Downloads/esfdt/FavFas.csv",
            "C:/Users/antho/Downloads/esfdt/Img_Clima.csv",
            "C:/Users/antho/Downloads/esfdt/Img_Seg.csv",
            "C:/Users/antho/Downloads/esfdt/Rotu.csv",
            "C:/Users/antho/Downloads/esfdt/Seg.csv"
        }; //Lista com os Diretorios dos arquivos .csv

        //Definir os separadores de acordo com o utilizado nos arquivos .csv
        String csvSeparator = ";";
        String csvSeparator1 = "%";

        List<Object> textDurationList = new ArrayList<>();
        Instant inicio = Instant.now(); //Cronômetragem do tempo de Execução (início)

        // Leitura e inserção de dados da Tabela Projetos
        //filePaths[?] é o diretorio do arquivo .csv
        //csvSeparator1 é o separador
        //db é o Banco a fazer inserção
        readAndInsertProjetos(filePaths[0], csvSeparator1, db, textDurationList);

        // Leitura e inserção de dados da Tabela Recomendações
        readAndInsertRecomendacoes(filePaths[1], csvSeparator1, db, textDurationList);

        // Leitura e inserção de dados da Tabela Fungicidas
        readAndInsertFungicidas(filePaths[2], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Tab. Verd.
        readAndInsertTabVerd(filePaths[3], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Sementes
        readAndInsertSementes(filePaths[4], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Banco Imagens
        readAndInsertBancoImagens(filePaths[5], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Recomendações Fungicidas
        readAndInsertRecomendacoesFungicidas(filePaths[6], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Dados Climáticos
        readAndInsertDadosClimaticos(filePaths[7], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Dados Planta Soja
        readAndInsertDadosPlantaSoja(filePaths[8], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Classificações 
        readAndInsertClassificacoes(filePaths[9], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Favorabilidade Fas 
        readAndInsertFavorabilidadeFas(filePaths[10], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Imagens Segmentadas 
        readAndInsertImagensSegmentadas(filePaths[12], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Segmentação 
        readAndInsertSegmentacao(filePaths[14], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Rótulo Segmentado 
        readAndInsertRotuloSegmentado(filePaths[13], csvSeparator, db, textDurationList);

        // Leitura e inserção de dados da Tabela Clima Favorab. 
        readAndInsertImagensClimaFavorab(filePaths[11], csvSeparator, db, textDurationList);
        Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
        Duration duracao = Duration.between(inicio, fim); // Calcula a duração
        System.out.println("Tempo de execução das operações de Inserções: " + duracao.toMillis() + " min"); //Exibir duração da execução
        textDurationList.clear();
        
        inicio = Instant.now();
        // Consulta 1
        Consulta1(db, textDurationList);

        // Consulta 2
        Consulta2(db, textDurationList);

        // Consulta 3
        Consulta3(db, textDurationList);

        // Consulta 4
        Consulta4(db, textDurationList);

        // Consulta 5
        Consulta5(db, textDurationList);

        // Consulta 6
        Consulta6(db, textDurationList);

        // Consulta 7
        Consulta7(db, textDurationList);

        // Consulta 8
        Consulta8(db, textDurationList);

        // Consulta 9
        Consulta9(db, textDurationList);

        // Consulta 10
        Consulta10(db, textDurationList);

        // Consulta 11
        Consulta11(db, textDurationList);

        // Consulta 12
        Consulta12(db, textDurationList);

        // Consulta 13
        Consulta13(db, textDurationList);

        // Consulta 14
        Consulta14(db, textDurationList);

        // Consulta 15
        Consulta15(db, textDurationList);

        // Consulta 16
        Consulta16(db, textDurationList);

        // Consulta 17
        Consulta17(db, textDurationList);

        // Consulta 18
        Consulta18(db, textDurationList);

        // Consulta 19
        Consulta19(db, textDurationList);

        // Consulta 20
        Consulta20(db, textDurationList);

        fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
        duracao = Duration.between(inicio, fim); // Calcula a duração
        System.out.println("Tempo de execução das operações de Consulta: " + duracao.toMillis() + " min"); //Exibir duração da execução
        textDurationList.clear();
        
        inicio = Instant.now();
        //Update 1
        Update1(db, textDurationList);

        //Update 2
        Update2(db, textDurationList);

        //Update 6
        Update3(db, textDurationList);

        //Update 4
        Update4(db, textDurationList);

        //Update 5
        Update5(db, textDurationList);

        //Update 6
        Update6(db, textDurationList);

        //Update 7
        Update7(db, textDurationList);

        //Update 8
        Update8(db, textDurationList);

        //Update 9
        Update9(db, textDurationList);

        //Update 10
        Update10(db, textDurationList);

        //Update 11
        Update11(db, textDurationList);

        //Update 12
        Update12(db, textDurationList);

        //Update 13
        Update13(db, textDurationList);

        //Update 14
        Update14(db, textDurationList);

        //Update 15
        Update15(db, textDurationList);

        //Update 16
        Update16(db, textDurationList);

        //Update 17
        Update17(db, textDurationList);

        //Update 18
        Update18(db, textDurationList);

        //Update 19
        Update19(db, textDurationList);

        //Update 20
        Update20(db, textDurationList);
        
        fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
        duracao = Duration.between(inicio, fim); // Calcula a duração
        System.out.println("Tempo de execução das operações de Update: " + duracao.toMillis() + " min"); //Exibir duração da execução
        textDurationList.clear();
        
        inicio = Instant.now();
        //Exclusão 1
        Exclusao1(db, textDurationList);

        //Exclusão 2
        Exclusao2(db, textDurationList);

        //Exclusão 3
        Exclusao3(db, textDurationList);

        //Exclusão 4
        Exclusao4(db, textDurationList);

        //Exclusão 5
        Exclusao5(db, textDurationList);

        //Exclusão 6
        Exclusao6(db, textDurationList);

        //Exclusão 7
        Exclusao7(db, textDurationList);

        //Exclusão 8
        Exclusao8(db, textDurationList);

        //Exclusão 9
        Exclusao9(db, textDurationList);

        //Exclusão 10
        Exclusao10(db, textDurationList);

        //Exclusão 11
        Exclusao11(db, textDurationList);

        //Exclusão 12
        Exclusao12(db, textDurationList);

        //Exclusão 13
        Exclusao13(db, textDurationList);

        //Exclusão 14
        Exclusao14(db, textDurationList);

        //Exclusão 15
        Exclusao15(db, textDurationList);

        //Exclusão 16
        Exclusao16(db, textDurationList);

        //Exclusão 17
        Exclusao17(db, textDurationList);

        //Exclusão 18
        Exclusao18(db, textDurationList);

        //Exclusão 19
        Exclusao19(db, textDurationList);

        //Exclusão 20
        Exclusao20(db, textDurationList);
        
        fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
        duracao = Duration.between(inicio, fim); // Calcula a duração
        System.out.println("Tempo de execução das operações de Consulta: " + duracao.toMillis() + " min"); //Exibir duração da execução
        textDurationList.clear();

        /* Exibe todos os objetos inseridos de todas os tipos
        displayStoredObjects(db); */
        db.close();
    }

    public static ObjectContainer configureAndOpenDb(String fileName) {
        EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();

        // Lista de classes que precisam de configuração (do segundo código)
        Class<?>[] classesToConfigure = {
            Projetos.class,
            Recomendacoes.class,
            Fungicidas.class,
            TabVerdFavorabilidade.class,
            Sementes.class,
            BancoImagens.class,
            RecomendacoesFungicidas.class,
            DadosClimaticos.class,
            DadosPlantaSoja.class,
            Classificacoes.class,
            FavorabilidadesFas.class,
            ImagensSegmentadas.class,
            Segmentacao.class,
            RotuloSegmentados.class,
            ImagemClimaFavorab.class
        // Adicione outras classes conforme necessário
        };

        // Configurações de cascade para todas as classes listadas
        for (Class<?> clazz : classesToConfigure) {
            config.common().objectClass(clazz).cascadeOnUpdate(true);
            config.common().objectClass(clazz).cascadeOnDelete(true);
        }

        // Abrindo o banco de dados com as configurações aplicadas
        return Db4oEmbedded.openFile(config, fileName);
    }

    //Método de conversão de Imagens de Hexadecimal para binário
    private static byte[] hexStringToByteArray(String s) {
        // Remove todos os caracteres que não sejam válidos em hexadecimal
        s = s.replaceAll("[^0-9A-Fa-f]", "");

        // Se o comprimento for ímpar, adicione um zero à frente
        if (s.length() % 2 != 0) {
            s = "0" + s;
        }

        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    // Método para ler e inserir recomendações
    private static void readAndInsertRecomendacoes(String filePath, String csvSeparator1, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator1);
                if (values.length < 3) {
                    System.out.println("Linha malformada ou incompleta: " + line);
                    continue; // Pula linhas malformadas
                }
                try {
                    Integer id = null;
                    String recomendacaoFavorabBaixa = values[0].trim();
                    String recomendacaoFavorabMedia = values[1].trim();
                    String recomendacaoFavorabAlta = values[2].trim();

                    Recomendacoes recomendacao = new Recomendacoes(id, recomendacaoFavorabBaixa, recomendacaoFavorabMedia, recomendacaoFavorabAlta);
                    db.store(recomendacao);
                    System.out.println("Inserido no DB4O: " + recomendacao);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Recomendações");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir projetos
    private static void readAndInsertProjetos(String filePath, String csvSeparator1, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator1);
                try {
                    Integer id = null;
                    String nomeProjeto = values[0];
                    String tipoProjeto = values[1];

                    Projetos projeto = new Projetos(id, nomeProjeto, tipoProjeto);
                    db.store(projeto);
                    System.out.println("Inserido no DB4O: " + projeto);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Projetos");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir fungicidas
    private static void readAndInsertFungicidas(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                if (values.length < 6) {
                    System.out.println("Linha malformada ou incompleta: " + line);
                    continue; // Pula linhas malformadas
                }
                try {
                    Integer id = null;
                    String tratamento = values[0].replace("\"", "").trim();
                    String dosagem1 = values[1].replace("\"", "").trim();
                    String dosagem2 = values[2].replace("\"", "").trim();
                    double severidade = Double.parseDouble(values[3].trim().replace(",", "."));
                    double porcentagemControle = Double.parseDouble(values[4].trim().replace(",", "."));
                    Integer produtividade = Integer.valueOf(values[5].trim());

                    Fungicidas fungicida = new Fungicidas(id, tratamento, dosagem1, dosagem2, severidade, porcentagemControle, produtividade);
                    db.store(fungicida);
                    System.out.println("Inserido no DB4O: " + fungicida);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Fungicidas");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir TabVerdFavorabilidade
    private static void readAndInsertTabVerd(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int v1 = Integer.parseInt(values[0].trim());
                    int v2 = Integer.parseInt(values[1].trim());
                    int v3 = Integer.parseInt(values[2].trim()); // v3 (integer)
                    int v4 = Integer.parseInt(values[3].trim()); // v4 (integer)
                    int v5 = Integer.parseInt(values[4].trim()); // v5 (integer)
                    int v6 = Integer.parseInt(values[5].trim()); // v6 (integer)
                    int v7 = Integer.parseInt(values[6].trim()); // v7 (integer)
                    int s = Integer.parseInt(values[7].trim()); // s (integer)
                    double pV1 = Double.parseDouble(values[8].trim()); // p_v1 (double precision)
                    double pV2 = Double.parseDouble(values[9].trim()); // p_v2 (double precision)
                    double pV3 = Double.parseDouble(values[10].trim()); // p_v3 (double precision)
                    double pV4 = Double.parseDouble(values[11].trim()); // p_v4 (double precision)
                    double pV5 = Double.parseDouble(values[12].trim()); // p_v5 (double precision)
                    double pV6 = Double.parseDouble(values[13].trim()); // p_v6 (double precision)
                    double pV7 = Double.parseDouble(values[14].trim()); // p_v7 (double precision)
                    TabVerdFavorabilidade tabV = new TabVerdFavorabilidade(id, v1, v2, v3, v4, v5, v6, v7, s, pV1, pV2, pV3, pV4, pV5, pV6, pV7);
                    db.store(tabV);

                    System.out.println("Inserido no DB4O: " + tabV);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de TabVerd");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Sementes
    private static void readAndInsertSementes(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now(); //Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    String descricaoCorSemente = values[0];
                    String corRgbSemente = values[1];
                    String dadosSementes = values[2];

                    Sementes seme = new Sementes(id, descricaoCorSemente, corRgbSemente, dadosSementes);
                    db.store(seme);
                    System.out.println("Inserido no DB4O: " + seme);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Sementes");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Banco_Imagens
    private static void readAndInsertBancoImagens(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int projetoId = Integer.parseInt(values[0].trim());
                    String descricaoImgOriginal = values[1]; // descricao_img_original (character varying)
                    String imgOriginalBase = values[2].trim();
                    byte[] imgOriginal = hexStringToByteArray(imgOriginalBase);
                    int alturaImgOriginal = Integer.parseInt(values[3].trim()); // altura_img_original (integer)
                    int larguraImgOriginal = Integer.parseInt(values[4].trim()); // largura_img_original (integer)
                    int numCanaisImgOriginal = Integer.parseInt(values[5].trim()); // num_canais_img_original (integer)
                    int totalPixelsImgOriginal = Integer.parseInt(values[6].trim()); // total_pixels_img_original (integer)
                    String tipoImgOriginal = values[7];

                    BancoImagens bancoImagens = new BancoImagens(id, descricaoImgOriginal, imgOriginal, alturaImgOriginal,
                            larguraImgOriginal, numCanaisImgOriginal, totalPixelsImgOriginal, tipoImgOriginal);
                    bancoImagens.adicionarAoProjeto(projetoId, db);
                    db.store(bancoImagens);
                    System.out.println("Inserido no DB4O: " + bancoImagens);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Banco Imagens");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Classificacoes
    private static void readAndInsertClassificacoes(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int projetoId = Integer.parseInt(values[0].trim());
                    int resultado = Integer.parseInt(values[1].trim());
                    int bancoId = Integer.parseInt(values[2].trim());
                    int porcentagemTreino = Integer.parseInt(values[3].trim());
                    int porcentagemTeste = Integer.parseInt(values[4].trim());
                    String tipoClassificacao = values[5];
                    String relatorioClassificacao = values[6];
                    String matrizConfusaoBase = values[7];
                    byte[] matrizConfusao = hexStringToByteArray(matrizConfusaoBase);  // img_original (bytea)
                    String curvaRocBase = values[8];
                    byte[] curvaRoc = hexStringToByteArray(curvaRocBase); // img_original (bytea)
                    Integer tuplasBinarias = Integer.valueOf(values[9].trim()); // altura_img_original (integer)
                    Integer tuplasBinariasLimpas = Integer.valueOf(values[10].trim()); // largura_img_original (integer)
                    double percTuplasDuplElimin = Double.parseDouble(values[3].trim().replace(",", "."));

                    Classificacoes clas = new Classificacoes(id, resultado, porcentagemTreino, porcentagemTeste, tipoClassificacao,
                            relatorioClassificacao, matrizConfusao, curvaRoc, tuplasBinarias, tuplasBinariasLimpas, percTuplasDuplElimin);
                    clas.adicionarAoBancoImagens(bancoId, db);
                    clas.adicionarAoProjeto(projetoId, db);
                    db.store(clas);
                    System.out.println("Inserido no DB4O: " + clas);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Classificações");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Dados Climaticos
    private static void readAndInsertDadosClimaticos(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int projetoId = Integer.parseInt(values[0].trim());
                    String localEstacaoClimatica = values[1]; // descricao_img_original (character varying)
                    String periodoMedicao = values[2];
                    DateTimeFormatter formatar = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate dataMedicao = LocalDate.parse(values[3].trim(), formatar); // data_medicao (date)
                    double precipitacao = Double.parseDouble(values[4].trim().replace(",", ".")); // precipitacao (double precision)
                    double temperaturaMax = Double.parseDouble(values[5].trim().replace(",", ".")); // temperatura_max (double precision)
                    double temperaturaMin = Double.parseDouble(values[6].trim().replace(",", ".")); // temperatura_min (double precision)
                    double umidadeRelativa = Double.parseDouble(values[7].trim().replace(",", ".")); // umidade_relativa (double precision)
                    double pontoOrvalho = Double.parseDouble(values[8].trim().replace(",", ".")); // ponto_orvalho (double precision)
                    double temperaturaMedCompensada = Double.parseDouble(values[9].trim().replace(",", ".")); // temperatura_med_compensada (double precision)
                    String regiaoEstacaoClimatica = values[10]; // regiao_estacao_climatica (character varying)
                    String status = values[11];
                    DadosClimaticos dadosC = new DadosClimaticos(id, localEstacaoClimatica, periodoMedicao, dataMedicao, precipitacao,
                            temperaturaMax, temperaturaMin, umidadeRelativa, pontoOrvalho, temperaturaMedCompensada, regiaoEstacaoClimatica, status);
                    dadosC.adicionarAoProjeto(projetoId, db);
                    db.store(dadosC);
                    System.out.println("Inserido no DB4O: " + dadosC);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Dados Climáticos");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista);
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Dados PlantaSoja
    private static void readAndInsertDadosPlantaSoja(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int projetoId = Integer.parseInt(values[0].trim());
                    String variedadeCultura = values[1]; // variedade_cultura (character varying)
                    double distanciaLinhaCultura = Double.parseDouble(values[2].trim().replace(",", ".")); // distancia_linha_cultura (double precision)
                    double alturaPlantaCultura = Double.parseDouble(values[3].trim().replace(",", ".")); // altura_planta_cultura (double precision)
                    double distanciaPlantaCultura = Double.parseDouble(values[4].trim().replace(",", ".")); // distancia_planta_cultura (double precision)
                    Integer plantasMetroLinear = Integer.valueOf(values[5].trim()); // plantas_metro_linear (integer, pode ser null)
                    String status = values[6];

                    DadosPlantaSoja dadosP = new DadosPlantaSoja(id, variedadeCultura, distanciaLinhaCultura, alturaPlantaCultura,
                            distanciaPlantaCultura, plantasMetroLinear, status);
                    dadosP.adicionarAoProjeto(projetoId, db);
                    db.store(dadosP);
                    System.out.println("Inserido no DB4O: " + dadosP);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Dados Planta Soja");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Favorabilidade Fas
    private static void readAndInsertFavorabilidadeFas(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    String resultadoFavorabilidade = values[1]; // resultado_favorabilidade (character varying)
                    String vetorFavorabilidade = values[2]; // vetor_favorabilidade (character varying)
                    int bancoId = Integer.parseInt(values[3].trim());
                    DateTimeFormatter formatar = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate janelaTempoInicial = LocalDate.parse(values[4].trim(), formatar); // janela_tempo_inicial (date)
                    DateTimeFormatter formatar1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate janelaTempoFinal = LocalDate.parse(values[5].trim(), formatar1); // janela_tempo_final (date)
                    String abordagemFusaoDados = values[6]; // abordagem_fusao_dados (character varying)
                    Integer v1 = Integer.valueOf(values[7].trim()); // v1 (integer, pode ser null)
                    Integer v2 = Integer.valueOf(values[8].trim()); // v2 (integer, pode ser null)
                    Integer v3 = Integer.valueOf(values[9].trim()); // v3 (integer, pode ser null)
                    Integer v4 = Integer.valueOf(values[10].trim()); // v4 (integer, pode ser null)
                    Integer v5 = Integer.valueOf(values[11].trim()); // v5 (integer, pode ser null)
                    Integer v6 = Integer.valueOf(values[12].trim()); // v6 (integer, pode ser null)
                    Integer v7 = Integer.valueOf(values[13].trim()); // v7 (integer, pode ser null)

                    FavorabilidadesFas favFas = new FavorabilidadesFas(id, resultadoFavorabilidade, vetorFavorabilidade, janelaTempoInicial,
                            janelaTempoFinal, abordagemFusaoDados, v1, v2, v3, v4, v5, v6, v7);
                    favFas.adicionarAoBancoImagens(bancoId, db);
                    db.store(favFas);
                    System.out.println("Inserido no DB4O: " + favFas);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Favorabilidade Fas");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir ImagensClima Favorab
    private static void readAndInsertImagensClimaFavorab(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int bancoId = Integer.parseInt(values[0].trim());
                    int tabVerId = Integer.parseInt(values[1].trim());
                    int dadosCId = Integer.parseInt(values[2].trim());
                    String descFavorab = values[3]; // desc_favorab (character varying)
                    int dadosPId = Integer.parseInt(values[4].trim());

                    ImagemClimaFavorab imgClima = new ImagemClimaFavorab(id, descFavorab);
                    imgClima.adicionarAoBancoImagens(bancoId, db);
                    imgClima.adicionarAoTabVerdFavorabilidade(tabVerId, db);
                    imgClima.adicionarAoDadosClimaticos(dadosCId, db);
                    imgClima.adicionarAoDadosPlantaSoja(dadosPId, db);
                    db.store(imgClima);
                    System.out.println("Inserido no DB4O: " + imgClima);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Imagens Clima Favorab");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Imagens Segmentadas
    private static void readAndInsertImagensSegmentadas(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    String imgSegmentReferenciaBase = values[0];
                    byte[] imgSegmentReferencia = hexStringToByteArray(imgSegmentReferenciaBase); // img_segment_referencia (bytea)
                    String imgFiltroMedianaBase = values[1];
                    byte[] imgFiltroMediana = hexStringToByteArray(imgFiltroMedianaBase); // img_filtro_mediana (bytea)
                    String imgCanalVerdeBase = values[2];
                    byte[] imgCanalVerde = hexStringToByteArray(imgCanalVerdeBase); // img_canal_verde (bytea)
                    String imgJanelaBase = values[3];
                    byte[] imgJanela = hexStringToByteArray(imgJanelaBase); // img_janela (bytea)
                    String imgLimiarizadaBase = values[4];
                    byte[] imgLimiarizada = hexStringToByteArray(imgLimiarizadaBase); // img_limiarizada (bytea)
                    String classeCor = values[5]; // classe_cor (character varying)
                    String descricaoImgOrigem = values[6]; // descricao_img_origem (character varying)
                    int bancoId = Integer.parseInt(values[7].trim());
                    String imgRotuloEscolhidoBase = values[8];
                    byte[] imgRotuloEscolhido = hexStringToByteArray(imgRotuloEscolhidoBase); // img_rotulo_escolhido (bytea)
                    double mse = Double.parseDouble(values[9].trim().replace(",", ".")); // mse (double precision)
                    double psnr = Double.parseDouble(values[10].trim().replace(",", ".")); // psnr (double precision)
                    double ssim = Double.parseDouble(values[11].trim().replace(",", ".")); // ssim (double precision)
                    String histogramaBase = values[12];
                    byte[] histograma = hexStringToByteArray(histogramaBase); // histograma (bytea)
                    String boxplotSementesBase = values[13];
                    byte[] boxplotSementes = hexStringToByteArray(boxplotSementesBase); // boxplot_sementes (bytea)
                    String boxplotSementesCalculoBase = values[14];
                    byte[] boxplotSementesCalculo = hexStringToByteArray(boxplotSementesCalculoBase); // boxplot_sementes_calculo (bytea)
                    Integer outliersBoxplotSementes = Integer.valueOf(values[15].trim()); // outliers_boxplot_sementes (integer, pode ser null)
                    Integer outliersBoxplotSementesCalculo = Integer.valueOf(values[16].trim()); // outliers_boxplot_sementes_calculo (integer, pode ser null)
                    ImagensSegmentadas imgSeg = new ImagensSegmentadas(id, imgSegmentReferencia, imgFiltroMediana, imgCanalVerde, imgJanela, imgLimiarizada,
                            classeCor, descricaoImgOrigem, imgRotuloEscolhido, mse, psnr, ssim, histograma, boxplotSementes, boxplotSementesCalculo,
                            outliersBoxplotSementes, outliersBoxplotSementesCalculo);
                    imgSeg.adicionarAoBancoImagens(bancoId, db);
                    db.store(imgSeg);
                    System.out.println("Inserido no DB4O: " + imgSeg);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Imagens Segmentadas");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir ecomendacoes Fungicidas
    private static void readAndInsertRecomendacoesFungicidas(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int fungicidasId = Integer.parseInt(values[0].trim());
                    int recomendacoesId = Integer.parseInt(values[1].trim());

                    RecomendacoesFungicidas recomFung = new RecomendacoesFungicidas(id, fungicidasId, recomendacoesId);
                    recomFung.adicionarAoFungicidas(fungicidasId, db);
                    recomFung.adicionarAsRecomendacoes(recomendacoesId, db);
                    db.store(recomFung);
                    System.out.println("Inserido no DB4O: " + recomFung);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Recomendações Fungicidas");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Rotulo Segmentado
    private static void readAndInsertRotuloSegmentado(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int segmentacaoId = Integer.parseInt(values[0].trim());
                    String imgRotuloSegmentadoBase = values[1];
                    byte[] imgRotuloSegmentado = hexStringToByteArray(imgRotuloSegmentadoBase);
                    String classeCor = values[2];

                    RotuloSegmentados rotuloSeg = new RotuloSegmentados(id, imgRotuloSegmentado, classeCor);
                    rotuloSeg.adicionarAoSegmentacao(segmentacaoId, db);
                    db.store(rotuloSeg);
                    System.out.println("Inserido no DB4O: " + rotuloSeg);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Rótulo Segmentado");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

    // Método para ler e inserir Segmentacao
    private static void readAndInsertSegmentacao(String filePath, String csvSeparator, ObjectContainer db, List textDurationList) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            Instant inicio = Instant.now();//Cronômetragem do tempo de Execução (Início)
            br.readLine(); // Ignora o cabeçalho
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSeparator);
                try {
                    Integer id = null;
                    int projetoId = Integer.parseInt(values[0].trim());
                    int imagensSegmentadasId = Integer.parseInt(values[1].trim());
                    int sementesId = Integer.parseInt(values[2].trim());
                    String dataHoraProjeto = values[3]; // data_hora_projeto (character varying)
                    String coordenadasSementeCentral = values[4]; // coordenadas_semente_central (character varying)
                    String coordenadasCalcJanela = values[5]; // coordenadas_calc_janela (character varying)
                    int totalPixelsJanela = Integer.parseInt(values[6].trim()); // total_pixels_janela (integer)
                    int totalSementesCalculadas = Integer.parseInt(values[7].trim()); // total_sementes_calculadas (integer)
                    double erroEstatisticoCalculado = Double.parseDouble(values[8].trim().replace(",", ".")); // erro_estatistico_calculado (double precision)
                    String operacaoProjeto = values[9]; // operacao_projeto (character varying)
                    double desvioPadrao = Double.parseDouble(values[10].trim().replace(",", ".")); // desvio_padrao (double precision)
                    int limiar1Segmentacao = Integer.parseInt(values[11].trim());
                    int limiar2Segmentacao = Integer.parseInt(values[12].trim());
                    String faixaLimiares = values[13];
                    double varianciaSegmentacao = Double.parseDouble(values[14].trim().replace(",", "."));
                    String coordJanelaFinalObjInter = values[15];
                    String sementesCalculadasJanela = values[16];
                    String relatorioColetaAutSemente = values[17];
                    String relatorioDadosEstatisticos = values[18];

                    Segmentacao segmentacao = new Segmentacao(id, dataHoraProjeto, coordenadasSementeCentral, coordenadasCalcJanela, totalPixelsJanela,
                            totalSementesCalculadas, erroEstatisticoCalculado, operacaoProjeto, desvioPadrao, limiar1Segmentacao, limiar2Segmentacao,
                            faixaLimiares, varianciaSegmentacao, coordJanelaFinalObjInter, sementesCalculadasJanela, relatorioColetaAutSemente, relatorioDadosEstatisticos);
                    segmentacao.adicionarAoProjeto(projetoId, db);
                    segmentacao.adicionarAsImagensSegmentadas(imagensSegmentadasId, db);
                    segmentacao.adicionarAsSementes(sementesId, db);
                    db.store(segmentacao);
                    System.out.println("Inserido no DB4O: " + segmentacao);
                } catch (NumberFormatException e) {
                    System.out.println("Erro ao converter valor para número: " + values[0]);
                }
            }
            db.commit();
            Instant fim = Instant.now();//Cronômetragem do tempo de Execução (fim)
            textDurationList.add("Tempo de execução de Segmentação");// Insere um texto de identificação à lista
            textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
        } catch (IOException e) {
        }
    }

// Método para exibir os objetos armazenados
    private static void displayStoredObjects(ObjectContainer db) {
        /*ObjectSet<Object> allObjects = db.queryByExample(Object.class);
        System.out.println("Objetos encontrados no banco de dados:");
        if (allObjects.isEmpty()) {
            System.out.println("Nenhum objeto encontrado.");
        } else {
            for (Object obj : allObjects) {
                System.out.println(obj);
            }
        ObjectSet<MyClass> result = db.query(MyClass.class);
            for (MyClass obj : result) {
                System.out.println(obj);
            }*/
        ObjectSet<Projetos> projects = db.queryByExample(Projetos.class);
        System.out.println("Projetos encontrados no banco de dados:");

        if (projects.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (Projetos proj : projects) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<Recomendacoes> projectsRecom = db.queryByExample(Recomendacoes.class);
        System.out.println("Recomendacoes encontrados no banco de dados:");

        if (projectsRecom.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (Recomendacoes proj : projectsRecom) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<Fungicidas> projectsFung = db.queryByExample(Fungicidas.class);
        System.out.println("Fungicidas encontrados no banco de dados:");

        if (projectsFung.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (Fungicidas proj : projectsFung) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<TabVerdFavorabilidade> projectsTab = db.queryByExample(TabVerdFavorabilidade.class);
        System.out.println("TabVerdFavorabilidade encontrados no banco de dados:");

        if (projectsTab.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (TabVerdFavorabilidade proj : projectsTab) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<Sementes> projectsSementes = db.queryByExample(Sementes.class);
        System.out.println("Sementes encontrados no banco de dados:");

        if (projectsSementes.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (Sementes proj : projectsSementes) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<BancoImagens> projectsBanco = db.queryByExample(BancoImagens.class);
        System.out.println("BancoImagens encontrados no banco de dados:");

        if (projectsBanco.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (BancoImagens proj : projectsBanco) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<RecomendacoesFungicidas> projectsRecomFung = db.queryByExample(RecomendacoesFungicidas.class);
        System.out.println("RecomendacoesFungicidas encontrados no banco de dados:");

        if (projectsRecomFung.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (RecomendacoesFungicidas proj : projectsRecomFung) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<DadosClimaticos> projectsDadosClimaticos = db.queryByExample(DadosClimaticos.class);
        System.out.println("DadosClimaticos encontrados no banco de dados:");

        if (projectsDadosClimaticos.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (DadosClimaticos proj : projectsDadosClimaticos) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<DadosPlantaSoja> projectsDadosPlantaSoja = db.queryByExample(DadosPlantaSoja.class);
        System.out.println("DadosPlantaSoja encontrados no banco de dados:");

        if (projectsDadosPlantaSoja.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (DadosPlantaSoja proj : projectsDadosPlantaSoja) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<ImagemClimaFavorab> projectsImagemClimaFavorab = db.queryByExample(ImagemClimaFavorab.class);
        System.out.println("ImagemClimaFavorab encontrados no banco de dados:");

        if (projectsImagemClimaFavorab.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (ImagemClimaFavorab proj : projectsImagemClimaFavorab) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<ImagensSegmentadas> projectsImagensSegmentadas = db.queryByExample(ImagensSegmentadas.class);
        System.out.println("ImagensSegmentadas encontrados no banco de dados:");

        if (projectsImagensSegmentadas.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (ImagensSegmentadas proj : projectsImagensSegmentadas) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<Classificacoes> projectsClassificacoes = db.queryByExample(Classificacoes.class);
        System.out.println("Classificacoes encontrados no banco de dados:");

        if (projectsClassificacoes.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            for (Classificacoes proj : projectsClassificacoes) {
                System.out.println(proj);
            }
        }

        ObjectSet<FavorabilidadesFas> projectsFavorabilidadesFas = db.queryByExample(FavorabilidadesFas.class);
        System.out.println("FavorabilidadesFas encontrados no banco de dados:");

        if (projectsFavorabilidadesFas.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (FavorabilidadesFas proj : projectsFavorabilidadesFas) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<RotuloSegmentados> projectsRotuloSegmentados = db.queryByExample(RotuloSegmentados.class);
        System.out.println("RotuloSegmentados encontrados no banco de dados:");

        if (projectsRotuloSegmentados.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (RotuloSegmentados proj : projectsRotuloSegmentados) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }

        ObjectSet<Segmentacao> projectsSegmentacao = db.queryByExample(Segmentacao.class);
        System.out.println("Segmentacao encontrados no banco de dados:");

        if (projectsSegmentacao.isEmpty()) {
            System.out.println("Nenhum projeto encontrado.");
        } else {
            Instant inicio = Instant.now();
            for (Segmentacao proj : projectsSegmentacao) {
                System.out.println(proj);
            }
            Instant fim = Instant.now();
            Duration duracao = Duration.between(inicio, fim); // Calcula a duração
            System.out.println("Tempo de execução: " + duracao.toMillis() + " ms");
        }
    }

    private static void Consulta1(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        ObjectSet<DadosPlantaSoja> dadosPlantas = db.query(DadosPlantaSoja.class);
        for (DadosPlantaSoja dados : dadosPlantas) {
            long totalImagens = dados.getImagemClimaFavorabList().size();
            System.out.println("ID Dados Planta: " + dados.getId() + ", Total Imagens Clima Favoráveis: " + totalImagens);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 1");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Consulta2(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Consultar imagens segmentadas com psnr entre 11 e 14, ordenadas por psnr
        // Buscar sementes com base em segmentações de uma data específica
        ObjectSet<Sementes> sementes = db.query(Sementes.class);

        for (Sementes semente : sementes) {
            boolean possuiSegmentacaoNaData = semente.getSegmentacaoList().stream()
                    .anyMatch(seg -> seg.getDataHoraProjeto().toString().startsWith("2021-10-04"));

            if (possuiSegmentacaoNaData) {
                System.out.println("Semente encontrada: " + semente);
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 2");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Consulta3(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Ranqueia os dados climáticos dentro de cada projeto por data de medição (mais novo para mais velho)
        ObjectSet<Projetos> projetos = db.query(Projetos.class);

        for (Projetos projeto : projetos) {
            List<DadosClimaticos> dadosClimaticos = projeto.getDadosClimaticosList();

            dadosClimaticos.stream()
                    .sorted(Comparator.comparing(DadosClimaticos::getDataMedicao).reversed())
                    .forEachOrdered(dados -> System.out.println("Projeto ID: " + projeto.getId()
                    + ", Dados Climáticos ID: " + dados.getId()
                    + ", Data Medição: " + dados.getDataMedicao()));
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 3");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta4(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)

        // Consultar todas as segmentações
        Query query = db.query();
        query.constrain(Segmentacao.class);
        ObjectSet<Segmentacao> segmentacoes = query.execute();

        // Criar listas para armazenar os resultados
        List<Segmentacao> segmentacaoResult = new ArrayList<>();
        List<Sementes> sementesResult = new ArrayList<>();
        List<ImagensSegmentadas> imagensSegmentadasResult = new ArrayList<>();

        // Iterar sobre as segmentações para buscar as sementes e imagens_segmentadas
        for (Segmentacao segmentacao : segmentacoes) {
            // Buscar as sementes associadas à segmentação
            Query sementesQuery = db.query();
            sementesQuery.constrain(Sementes.class);
            sementesQuery.descend("id_sementes").constrain(segmentacao.getId()).equal();
            ObjectSet<Sementes> sementes = sementesQuery.execute();

            // Buscar as imagens_segmentadas associadas à segmentação
            Query imagensQuery = db.query();
            imagensQuery.constrain(ImagensSegmentadas.class);
            imagensQuery.descend("id_img_segmentadas").constrain(segmentacao.getId()).equal();
            ObjectSet<ImagensSegmentadas> imagensSegmentadas = imagensQuery.execute();

            // Adicionar aos resultados se encontrados
            if (sementes.hasNext()) {
                sementesResult.add(sementes.next());
            }
            if (imagensSegmentadas.hasNext()) {
                imagensSegmentadasResult.add(imagensSegmentadas.next());
            }

            segmentacaoResult.add(segmentacao);
        }

        // Aqui, você pode processar ou exibir os resultados das listas
        for (int i = 0; i < segmentacaoResult.size(); i++) {
            Segmentacao segmentacao = segmentacaoResult.get(i);
            Sementes sementes = sementesResult.get(i);
            ImagensSegmentadas imagens = imagensSegmentadasResult.get(i);

            System.out.println("Segmentação: " + segmentacao);
            System.out.println("Sementes: " + sementes);
            System.out.println("Imagens Segmentadas: " + imagens);
        }

        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 4");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Consulta5(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Contar quantos objetos `DadosPlantaSoja` fazem referência a `ImagemClimaFavorab`
        ObjectSet<DadosPlantaSoja> dadosPlantas = db.query(DadosPlantaSoja.class);
        long totalDadosPlantaSoja = dadosPlantas.stream()
                .filter(dados -> !dados.getImagemClimaFavorabList().isEmpty())
                .count();
        System.out.println("Total de DadosPlantaSoja relacionados: " + totalDadosPlantaSoja);

        // Contar quantos objetos `DadosClimaticos` fazem referência a `ImagemClimaFavorab`
        ObjectSet<DadosClimaticos> dadosClimaticos = db.query(DadosClimaticos.class);
        long totalDadosClimaticos = dadosClimaticos.stream()
                .filter(dados -> !dados.getImagemClimaFavorabList().isEmpty())
                .count();
        System.out.println("Total de DadosClimaticos relacionados: " + totalDadosClimaticos);

        // Contar quantos objetos `TabVerdFavorab` fazem referência a `ImagemClimaFavorab`
        ObjectSet<TabVerdFavorabilidade> tabVerdFavorab = db.query(TabVerdFavorabilidade.class);
        long totalTabVerdFavorab = tabVerdFavorab.stream()
                .filter(tab -> !tab.getImagemClimaFavorabList().isEmpty())
                .count();
        System.out.println("Total de TabVerdFavorab relacionados: " + totalTabVerdFavorab);

        // Contar quantos objetos `BancoImagens` fazem referência a `ImagemClimaFavorab`
        ObjectSet<BancoImagens> bancoImagens = db.query(BancoImagens.class);
        long totalBancoImagens = bancoImagens.stream()
                .filter(banco -> !banco.getImagemClimaFavorabList().isEmpty())
                .count();
        System.out.println("Total de BancoImagens relacionados: " + totalBancoImagens);
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 5");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta6(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Contar banco de imagens com múltiplas favorabilidades associadas
        ObjectSet<Sementes> sementes = db.query(Sementes.class);

        for (Sementes semente : sementes) {
            List<Segmentacao> segmentacoes = semente.getSegmentacaoList(); // Acesso à lista de segmentações na semente

            // Contar segmentações por banco de imagens
            Map<Integer, Long> segmentacoesPorBanco = segmentacoes.stream()
                    .collect(Collectors.groupingBy(Segmentacao::getId, Collectors.counting()));

            for (Map.Entry<Integer, Long> entry : segmentacoesPorBanco.entrySet()) {
                if (entry.getValue() > 1) {
                    System.out.println("Banco Imagens ID: " + entry.getKey() + ", Total Segmentações: " + entry.getValue());
                }
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 6");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta7(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Contar favorabilidades agrupadas por ano da janela inicial
        ObjectSet<FavorabilidadesFas> favorabilidades = db.query(FavorabilidadesFas.class);
        Map<Integer, Long> agrupadosPorAno = favorabilidades.stream()
                .collect(Collectors.groupingBy(f -> f.getJanelaTempoInicial().getYear(), Collectors.counting()));
        for (Map.Entry<Integer, Long> entry : agrupadosPorAno.entrySet()) {
            System.out.println("Ano: " + entry.getKey() + ", Quantidade: " + entry.getValue());
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 7");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta8(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
// Contar frequência de desc_favorab em ImagemClimaFavorab
        ObjectSet<ImagemClimaFavorab> imagens = db.query(ImagemClimaFavorab.class);
        Map<String, Long> frequencia = imagens.stream()
                .collect(Collectors.groupingBy(ImagemClimaFavorab::getDescFavorab, Collectors.counting()));
        for (Map.Entry<String, Long> entry : frequencia.entrySet()) {
            System.out.println("Descrição: " + entry.getKey() + ", Frequência: " + entry.getValue());
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 8");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta9(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Consulta para contar o total por descrição da cor da semente e ordenar de acordo com a lógica específica
        ObjectSet<Sementes> sementes = db.query(Sementes.class);

// Agrupar as sementes por descrição da cor da semente
        Map<String, Long> totalPorCor = sementes.stream()
                .map(Sementes::getDescricaoCorSemente) // Acessa a descrição da cor da semente
                .filter(cor -> cor != null) // Garante que a cor não seja nula
                .collect(Collectors.groupingBy(cor -> cor, Collectors.counting()));

// Ordenação personalizada diretamente com o stream
        totalPorCor.entrySet().stream()
                .sorted((entry1, entry2) -> {
                    String cor1 = entry1.getKey();
                    String cor2 = entry2.getKey();

                    // Ordenação de acordo com a lógica de cores: 'verde', 'amarela', 'marrom', outras
                    if (cor1.equals("verde")) {
                        return cor2.equals("verde") ? 0 : -1;
                    } else if (cor1.equals("amarela")) {
                        return cor2.equals("amarela") ? 0 : -1;
                    } else if (cor1.equals("marrom")) {
                        return cor2.equals("marrom") ? 0 : -1;
                    } else {
                        return 1;
                    }
                })
                .forEach(entry -> System.out.println("Cor: " + entry.getKey() + ", Total: " + entry.getValue()));
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 9");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta10(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Buscar todos os objetos de BancoImagens
        ObjectSet<BancoImagens> bancoImagensList = db.query(BancoImagens.class);

// Iterar sobre cada BancoImagens e contar o número de FavorabilidadesFas na lista
        for (BancoImagens bancoImagens : bancoImagensList) {
            long totalFavorabilidades = bancoImagens.getFavorabilidadesFasList().size();  // Contagem de FavorabilidadesFas associadas

            // Exibir o resultado apenas se o total de FavorabilidadesFas for maior que 0
            if (totalFavorabilidades > 0) {
                System.out.println("ID Banco Imagens: " + bancoImagens.getId() + ", Total Favorabilidades: " + totalFavorabilidades);
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 10");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta11(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Buscar todos os objetos FavorabilidadesFas
        ObjectSet<FavorabilidadesFas> favorabilidadesFas = db.query(FavorabilidadesFas.class);

        // Criar uma lista com os IDs que possuem "Favorabilidade Média" no resultado
        List<Integer> favorabilidadeIds = new ArrayList<>();
        for (FavorabilidadesFas f : favorabilidadesFas) {
            if (f.getResultadoFavorabilidade() != null && f.getResultadoFavorabilidade().contains("Favorabilidade Média")) {
                favorabilidadeIds.add(f.getId());
            }
        }

        // Filtrar os resultados e imprimir apenas os IDs
        favorabilidadesFas.stream()
                .filter(f -> favorabilidadeIds.contains(f.getId()))
                .map(FavorabilidadesFas::getId)
                .forEach(System.out::println);
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 11");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Consulta12(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Buscar todos os Projetos
        ObjectSet<Projetos> projetos = db.query(Projetos.class);
        // Iterar sobre os Projetos e suas Classificações
        for (Projetos projeto : projetos) {
            List<Classificacoes> classificacoes = projeto.getClassificacoesList();

            // Verifique se existem classificações
            if (!classificacoes.isEmpty()) {
                // Ordenar as classificações pela propriedade tuplas_binarias em ordem decrescente
                classificacoes.sort((c1, c2) -> Integer.compare(c2.getTuplasBinarias(), c1.getTuplasBinarias()));

                // Atribuir rank manualmente
                int rank = 1;
                for (Classificacoes classificacao : classificacoes) {
                    System.out.println("Projeto ID: " + projeto.getId() + ", Classificação ID: " + classificacao.getId()
                            + ", Rank: " + rank + ", Tuplas Binarias: " + classificacao.getTuplasBinarias());
                    rank++;  // Incrementa o rank
                }
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 12");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta13(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Consultar todos os objetos DadosClimaticos
        ObjectSet<DadosClimaticos> dadosClimaticosSet = db.query(DadosClimaticos.class);

// Consultar todos os objetos DadosPlantaSoja
        ObjectSet<DadosPlantaSoja> dadosPlantaSojaSet = db.query(DadosPlantaSoja.class);

// Estruturas para vincular os dados
        Map<Integer, DadosClimaticos> imagensPorDadosClimaticos = new HashMap<>();
        Map<Integer, DadosPlantaSoja> imagensPorDadosPlantaSoja = new HashMap<>();

// Processar os DadosClimaticos e suas imagens
        for (DadosClimaticos dadosClimaticos : dadosClimaticosSet) {
            for (ImagemClimaFavorab imagem : dadosClimaticos.getImagemClimaFavorabList()) {
                imagensPorDadosClimaticos.put(imagem.getId(), dadosClimaticos);
            }
        }

// Processar os DadosPlantaSoja e suas imagens
        for (DadosPlantaSoja dadosPlantaSoja : dadosPlantaSojaSet) {
            for (ImagemClimaFavorab imagem : dadosPlantaSoja.getImagemClimaFavorabList()) {
                imagensPorDadosPlantaSoja.put(imagem.getId(), dadosPlantaSoja);
            }
        }

        // Vincular os dados baseados nas imagens
        Set<Integer> imagensComuns = new HashSet<>(imagensPorDadosClimaticos.keySet());
        imagensComuns.retainAll(imagensPorDadosPlantaSoja.keySet()); // Interseção das imagens

        // Exibir os resultados vinculados
        for (Integer imagemId : imagensComuns) {
            DadosClimaticos dadosClimaticos = imagensPorDadosClimaticos.get(imagemId);
            DadosPlantaSoja dadosPlantaSoja = imagensPorDadosPlantaSoja.get(imagemId);

            // Exibindo os objetos inteiros
            System.out.println("Imagem Clima Favorab:");
            System.out.println(imagemId); // Exibir ID ou o próprio objeto, se necessário
            System.out.println("Dados Climáticos:");
            System.out.println(dadosClimaticos); // Exibir o objeto inteiro de DadosClimaticos
            System.out.println("Dados Planta Soja:");
            System.out.println(dadosPlantaSoja); // Exibir o objeto inteiro de DadosPlantaSoja
            System.out.println("-------------------------------------------------");
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 13");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta14(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Consulta para contar as chaves e total de relações únicas para cada objeto que contém segmentações
        ObjectSet<Sementes> sementes = db.query(Sementes.class);
        ObjectSet<ImagensSegmentadas> imagensSegmentadas = db.query(ImagensSegmentadas.class);
        ObjectSet<Projetos> projetos = db.query(Projetos.class);

// Contagem de 'chave_1' - Contagem de sementes únicas associadas a segmentações
        long chave1 = sementes.stream()
                .filter(s -> !s.getSegmentacaoList().isEmpty()) // Verifica se a semente tem segmentações associadas
                .count(); // Conta as sementes que têm segmentações

// Contagem de 'chave_2' - Contagem de imagens segmentadas únicas associadas a segmentações
        long chave2 = imagensSegmentadas.stream()
                .filter(i -> !i.getSegmentacaoList().isEmpty()) // Verifica se a imagem segmentada tem segmentações associadas
                .count(); // Conta as imagens segmentadas que têm segmentações

// Contagem de 'chave_3' - Contagem de projetos únicos associados a segmentações
        long chave3 = projetos.stream()
                .filter(p -> !p.getSegmentacaoList().isEmpty()) // Verifica se o projeto tem segmentações associadas
                .count(); // Conta os projetos que têm segmentações

// Exibindo os resultados
        System.out.println("chave_1: " + chave1); // Quantidade de sementes com segmentações
        System.out.println("chave_2: " + chave2); // Quantidade de imagens segmentadas com segmentações
        System.out.println("chave_3: " + chave3); // Quantidade de projetos com segmentações
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 14");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta15(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Obter todos os dados de planta
        ObjectSet<DadosPlantaSoja> dadosPlanta = db.query(DadosPlantaSoja.class);

// Criar um Map para contar as imagens climáticas favoráveis
        Map<Integer, Long> contagemPorDadosPlantaSoja = new HashMap<>();

// Iterar sobre os dados das plantas
        for (DadosPlantaSoja planta : dadosPlanta) {
            // Verificar se a lista de imagens climáticas favoráveis não está vazia
            List<ImagemClimaFavorab> imagensClimaFavorab = planta.getImagemClimaFavorabList();
            if (imagensClimaFavorab != null && !imagensClimaFavorab.isEmpty()) {
                System.out.println("Dados Planta ID: " + planta.getId() + ", Imagens encontradas: " + imagensClimaFavorab.size());

                // Iterar sobre as imagens climáticas favoráveis associadas a cada planta
                for (ImagemClimaFavorab imagem : imagensClimaFavorab) {
                    // Verificar se a imagem tem id_dados_planta_soja e contar a quantidade
                    int idDadosPlantaSoja = imagem.getId();
                    contagemPorDadosPlantaSoja.put(idDadosPlantaSoja,
                            contagemPorDadosPlantaSoja.getOrDefault(idDadosPlantaSoja, 0L) + 1);
                }
            } else {
                System.out.println("Dados Planta ID: " + planta.getId() + " não tem imagens associadas.");
            }
        }

// Exibir os resultados com contagem maior que 1
        for (Map.Entry<Integer, Long> entry : contagemPorDadosPlantaSoja.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println("ID Dados Planta Soja: " + entry.getKey() + ", Contagem: " + entry.getValue());
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 15");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Consulta16(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)

        // Consultar imagens com psnr entre 11 e 14
        Query query = db.query();
        query.constrain(ImagensSegmentadas.class);
        query.descend("psnr").constrain(11).greater().and(query.descend("psnr").constrain(14).smaller());
        ObjectSet result = query.execute();

        // Ordenar o resultado por psnr em ordem crescente (isso pode ser feito após a consulta)
        List<ImagensSegmentadas> imagens = new ArrayList<>();
        while (result.hasNext()) {
            imagens.add((ImagensSegmentadas) result.next());
        }

        imagens.sort(Comparator.comparingDouble(ImagensSegmentadas::getPsnr));

        // Exibir ou processar os resultados
        for (ImagensSegmentadas imagem : imagens) {
            System.out.println(imagem);
        }

        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 16");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Consulta17(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Busca de dados de CLASSIFICACOES com base em IMAGEM_CLIMA_FAVORAB
        ObjectSet<Classificacoes> classificacoes = db.query(Classificacoes.class);
        for (Classificacoes classificacao : classificacoes) {
            // Itera sobre as listas de imagens climáticas dentro de BancoImagens
            for (BancoImagens bancoImagens : db.query(BancoImagens.class)) {
                // Verifica se BancoImagens contém a imagem climática associada
                for (ImagemClimaFavorab imagemClima : bancoImagens.getImagemClimaFavorabList()) {
                    DadosClimaticos dadosClimaticos = null;
                    // Itera sobre a lista de imagens climáticas dentro de DadosClimaticos
                    for (DadosClimaticos dados : db.query(DadosClimaticos.class)) {
                        if (dados.getImagemClimaFavorabList().contains(imagemClima)) {
                            dadosClimaticos = dados;
                            break;
                        }
                    }

                    if (dadosClimaticos != null) {
                        // Verifica se o ID_DADOS_CLIMATICOS é o mínimo dentro da lista de imagens climáticas favoráveis
                        Integer minIdDadosClimaticos = dadosClimaticos.getImagemClimaFavorabList().stream()
                                .map(ImagemClimaFavorab::getId)
                                .min(Integer::compare)
                                .orElse(null);

                        Integer minIdBancoImagens = bancoImagens.getImagemClimaFavorabList().stream()
                                .map(ImagemClimaFavorab::getId)
                                .min(Integer::compare)
                                .orElse(null);

                        // Compara se a imagem climática tem os IDs mínimos dos respectivos DadosClimaticos e BancoImagens
                        if (minIdDadosClimaticos != null && minIdBancoImagens != null && imagemClima.getId().equals(minIdDadosClimaticos) && imagemClima.getId().equals(minIdBancoImagens)) {
                            // Verifica a data de medição para o intervalo
                            if (dadosClimaticos.getDataMedicao().isAfter(LocalDate.of(2014, 10, 4)) && dadosClimaticos.getDataMedicao().isBefore(LocalDate.of(2015, 11, 4))) {
                                System.out.println("RESULTADO: " + classificacao.getResultado());
                            }
                        }
                    }
                }
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 17");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Consulta18(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
// Busca de todas as classificações
        ObjectSet<Classificacoes> classificacoes = db.query(Classificacoes.class);

        for (Classificacoes classificacao : classificacoes) {
            // Itera sobre os BancoImagens para obter as imagens climáticas associadas
            for (BancoImagens bancoImagens : db.query(BancoImagens.class)) {
                // Itera sobre a lista de imagens climáticas favoráveis associadas ao BancoImagens
                for (ImagemClimaFavorab imagemClima : bancoImagens.getImagemClimaFavorabList()) {
                    // Itera sobre os DadosClimaticos para encontrar o primeiro com a data dentro do intervalo
                    for (DadosClimaticos dadosClimaticos : db.query(DadosClimaticos.class)) {
                        if (dadosClimaticos.getDataMedicao().isAfter(LocalDate.of(2015, 10, 4))
                                && dadosClimaticos.getDataMedicao().isBefore(LocalDate.of(2015, 10, 20))) {

                            // Verifica se o ID_DADOS_CLIMATICOS é o mínimo dentro da lista de imagens climáticas favoráveis
                            Integer minIdDadosClimaticos = dadosClimaticos.getImagemClimaFavorabList().stream()
                                    .map(ImagemClimaFavorab::getId)
                                    .min(Integer::compare)
                                    .orElse(null);

                            // Verifica se o ID_BANCO_IMAGENS é o mínimo dentro da lista de imagens climáticas
                            Integer minIdBancoImagens = bancoImagens.getImagemClimaFavorabList().stream()
                                    .map(ImagemClimaFavorab::getId)
                                    .min(Integer::compare)
                                    .orElse(null);

                            // Comparação de IDs mínimos
                            if (imagemClima.getId().equals(minIdDadosClimaticos) && imagemClima.getId().equals(minIdBancoImagens)) {
                                // Se os IDs corresponderem, imprime a CURVA_ROC da CLASSIFICACOES
                                System.out.println("CURVA_ROC: " + classificacao.getCurvaRoc());
                            }
                        }
                    }
                }
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 18");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Consulta19(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Busca todos os DadosClimaticos
        ObjectSet<DadosClimaticos> dadosClimaticos = db.query(DadosClimaticos.class);

// Mapa para agrupar as classificações por data e tipo
        Map<LocalDate, Map<String, List<Classificacoes>>> agrupadosPorDataETipo = new HashMap<>();

// Itera sobre todos os DadosClimaticos
        for (DadosClimaticos dc : dadosClimaticos) {
            // Itera sobre a lista de ImagemClimaFavorab associada ao DadosClimaticos
            for (ImagemClimaFavorab icf : dc.getImagemClimaFavorabList()) {
                // Itera sobre todos os BancoImagens para encontrar a classificação associada
                for (BancoImagens banco : db.query(BancoImagens.class)) {
                    // Verifica se a imagem climática está na lista de imagens do BancoImagens
                    if (banco.getImagemClimaFavorabList().contains(icf)) {
                        // Itera sobre as classificações associadas ao BancoImagens
                        for (Classificacoes c : banco.getClassificacoesList()) {
                            // Agrupa as classificações por data_medicao e tipo_classificacao
                            agrupadosPorDataETipo
                                    .computeIfAbsent(dc.getDataMedicao(), k -> new HashMap<>())
                                    .computeIfAbsent(c.getTipoClassificacao(), k -> new ArrayList<>())
                                    .add(c);
                        }
                    }
                }
            }
        }

// Agora, vamos calcular as médias e o desempenho ajustado
        for (Map.Entry<LocalDate, Map<String, List<Classificacoes>>> entradaData : agrupadosPorDataETipo.entrySet()) {
            LocalDate dataMedicao = entradaData.getKey();
            Map<String, List<Classificacoes>> gruposPorTipo = entradaData.getValue();

            for (Map.Entry<String, List<Classificacoes>> entradaTipo : gruposPorTipo.entrySet()) {
                String tipoClassificacao = entradaTipo.getKey();
                List<Classificacoes> classificacoes = entradaTipo.getValue();

                // Calcula a média de porcentagem_treino e porcentagem_teste
                double mediaTreino = classificacoes.stream()
                        .mapToDouble(Classificacoes::getPorcentagemTreino)
                        .average()
                        .orElse(0);

                double mediaTeste = classificacoes.stream()
                        .mapToDouble(Classificacoes::getPorcentagemTeste)
                        .average()
                        .orElse(0);

                // Calcula o desempenho ajustado (média das classificações anteriores)
                double desempenhoAjustado = dadosClimaticos.stream()
                        .filter(dc2 -> dc2.getDataMedicao().isBefore(dataMedicao))
                        .flatMap(dc2 -> dc2.getImagemClimaFavorabList().stream())
                        .flatMap(imagemClima -> db.query(BancoImagens.class).stream()
                        .filter(b -> b.getImagemClimaFavorabList().contains(imagemClima))
                        .flatMap(b -> b.getClassificacoesList().stream()))
                        .mapToDouble(Classificacoes::getPorcentagemTeste)
                        .average()
                        .orElse(0);

                // Exibe os resultados
                System.out.println("Data Medição: " + dataMedicao
                        + ", Tipo Classificação: " + tipoClassificacao
                        + ", Média Treino: " + mediaTreino
                        + ", Média Teste: " + mediaTeste
                        + ", Desempenho Ajustado: " + desempenhoAjustado);
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 19");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista

    }

    private static void Consulta20(ObjectContainer db, List textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Buscar todos os DadosClimaticos onde temperatura_max > 35 ou temperatura_min < 5
        ObjectSet<DadosClimaticos> dadosClimaticos = db.query(DadosClimaticos.class);
        for (DadosClimaticos dc : dadosClimaticos) {
            if (dc.getTemperaturaMax() <= 35 && dc.getTemperaturaMin() >= 5) {
                continue; // Filtra os que não atendem à condição
            }
            // Criar um mapa para contar o total de classificações por tipo
            Map<String, Long> totalClassificacoesPorTipo = new HashMap<>();

            // Percorrer todas as imagens climáticas favoráveis associadas a esse dado climático
            for (ImagemClimaFavorab icf : dc.getImagemClimaFavorabList()) {

                // Acessar todos os bancos de imagens que contêm esta imagem
                for (BancoImagens bancoImagens : db.query(BancoImagens.class)) {
                    if (!bancoImagens.getImagemClimaFavorabList().contains(icf)) {
                        continue; // Garante que a imagem pertence ao banco
                    }
                    // Obter todas as classificações associadas ao banco de imagens
                    for (Classificacoes c : bancoImagens.getClassificacoesList()) {
                        totalClassificacoesPorTipo.merge(c.getTipoClassificacao(), 1L, Long::sum);
                    }
                }
            }

            // Calcular o desempenho ajustado para este conjunto de DadosClimaticos
            double desempenhoAjustado = db.query(DadosClimaticos.class).stream()
                    .filter(dc2 -> dc2.getDataMedicao().isBefore(dc.getDataMedicao())
                    && (dc2.getTemperaturaMax() > 35 || dc2.getTemperaturaMin() < 5))
                    .flatMap(dc2 -> dc2.getImagemClimaFavorabList().stream()) // Obter todas as imagens climáticas
                    .flatMap(icf2 -> db.query(BancoImagens.class).stream() // Buscar os bancos de imagens
                    .filter(bi -> bi.getImagemClimaFavorabList().contains(icf2))
                    .flatMap(bi -> bi.getClassificacoesList().stream())) // Buscar todas as classificações
                    .mapToDouble(Classificacoes::getPorcentagemTeste) // Extrair a porcentagem de teste
                    .average()
                    .orElse(0);

            // Imprimir os resultados agrupados por data de medição e tipo de classificação
            for (Map.Entry<String, Long> entry : totalClassificacoesPorTipo.entrySet()) {
                System.out.println("Data Medição: " + dc.getDataMedicao()
                        + ", Tipo Classificação: " + entry.getKey()
                        + ", Total Classificações: " + entry.getValue()
                        + ", Desempenho Ajustado: " + desempenhoAjustado);
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Consutal 20");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    private static void Update1(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<Classificacoes> resultado1 = db.queryByExample(new Classificacoes(1)); // Substituir pelo ID correto
        if (!resultado1.isEmpty()) {
            Classificacoes classificacao1 = resultado1.next();
            classificacao1.setRelatorioClassificacao("""
                                                     SVM Classifier Data (Binary) ---> Image: DSC_0016.jpg
                                                     Percentage of 70.0% for Training and 30.0% for Test
                                                     Accuracy(SVM): 0.812345678912345
                                                     Standard Deviation(SVM): [0.0123456789012345]
                                                     Mean Squared Error = 0.187654321098765
                                                     Classification Report: precision recall f1-score support
                                                     0 0.75 0.65 0.70 500
                                                     1 0.85 0.90 0.87 1500
                                                     accuracy 0.81 2000
                                                     macro avg 0.80 0.77 0.78 2000
                                                     weighted avg 0.81 0.81 0.81 2000
                                                     ----------------------------------
                                                     Dados Curva ROC AUC(Area Under the Curve - SVM): 0.88""");
            db.store(classificacao1);
        }

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 1");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 2
    private static void Update2(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<Classificacoes> resultado2 = db.queryByExample(new Classificacoes(2)); // Substituir pelo ID correto
        if (!resultado2.isEmpty()) {
            Classificacoes classificacao2 = resultado2.next();
            classificacao2.setRelatorioClassificacao("""
                                                     SVM Classifier Data (Binary) ---> Image: IMG_0050.png
                                                     Percentage of 75.0% for Training and 25.0% for Test
                                                     Accuracy(SVM): 0.845987654321098
                                                     Standard Deviation(SVM): [0.0087654321098765]
                                                     Mean Squared Error = 0.154012345678901
                                                     Classification Report: precision recall f1-score support
                                                     0 0.78 0.68 0.73 800
                                                     1 0.87 0.91 0.89 1600
                                                     accuracy 0.85 2400
                                                     macro avg 0.82 0.79 0.81 2400
                                                     weighted avg 0.85 0.85 0.85 2400
                                                     ----------------------------------
                                                     Dados Curva ROC AUC(Area Under the Curve - SVM): 0.91""");
            db.store(classificacao2);
        }

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 2");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 3
    private static void Update3(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<Classificacoes> resultado3 = db.queryByExample(new Classificacoes(3)); // Substituir pelo ID correto
        if (!resultado3.isEmpty()) {
            Classificacoes classificacao3 = resultado3.next();
            classificacao3.setRelatorioClassificacao("""
                                                     SVM Classifier Data (Binary) ---> Image: DSC_0020.jpg
                                                     Percentage of 80.0% for Training and 20.0% for Test
                                                     Accuracy(SVM): 0.8301020304050607
                                                     Standard Deviation(SVM): [0.0112345678901234]
                                                     Mean Squared Error = 0.169897969594939
                                                     Classification Report: precision recall f1-score support
                                                     0 0.79 0.66 0.72 900
                                                     1 0.86 0.92 0.89 1400
                                                     accuracy 0.83 2300
                                                     macro avg 0.83 0.79 0.81 2300
                                                     weighted avg 0.84 0.83 0.83 2300
                                                     ----------------------------------
                                                     Dados Curva ROC AUC(Area Under the Curve - SVM): 0.90""");
            db.store(classificacao3);
        }

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 3");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 4
    private static void Update4(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<Classificacoes> resultado4 = db.queryByExample(new Classificacoes(4)); // Substituir pelo ID correto
        if (!resultado4.isEmpty()) {
            Classificacoes classificacao4 = resultado4.next();
            classificacao4.setRelatorioClassificacao("""
                                                     SVM Classifier Data (Binary) ---> Image: IMG_0100.jpg
                                                     Percentage of 85.0% for Training and 15.0% for Test
                                                     Accuracy(SVM): 0.8765432109876543
                                                     Standard Deviation(SVM): [0.0065432109876543]
                                                     Mean Squared Error = 0.1234567890123456
                                                     Classification Report: precision recall f1-score support
                                                     0 0.81 0.72 0.76 850
                                                     1 0.88 0.94 0.91 1550
                                                     accuracy 0.88 2400
                                                     macro avg 0.85 0.83 0.84 2400
                                                     weighted avg 0.88 0.88 0.88 2400
                                                     ----------------------------------
                                                     Dados Curva ROC AUC(Area Under the Curve - SVM): 0.92""");
            db.store(classificacao4);
        }

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 4");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 5
    private static void Update5(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<DadosClimaticos> resultado5 = db.queryByExample(new DadosClimaticos(1));
        if (!resultado5.isEmpty()) {
            DadosClimaticos objeto5 = resultado5.next();
            objeto5.setRegiaoEstacaoClimatica("Região Norte");
            db.store(objeto5);
        }

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 5");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 6
    private static void Update6(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<DadosClimaticos> resultado6 = db.queryByExample(new DadosClimaticos(2));
        if (!resultado6.isEmpty()) {
            DadosClimaticos objeto6 = resultado6.next();
            objeto6.setRegiaoEstacaoClimatica("Região Sul");
            db.store(objeto6);

            Instant fimAlteracao = Instant.now();
            textDurationList.add("Tempo de Update 6");
            textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
        }
    }
    // Update 7

    private static void Update7(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<DadosClimaticos> resultado7 = db.queryByExample(new DadosClimaticos(3));
        if (!resultado7.isEmpty()) {
            DadosClimaticos objeto7 = resultado7.next();
            objeto7.setRegiaoEstacaoClimatica("Região Sudeste");
            db.store(objeto7);
        }

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 7");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 8
    private static void Update8(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<DadosClimaticos> resultado8 = db.queryByExample(new DadosClimaticos(4));
        if (!resultado8.isEmpty()) {
            DadosClimaticos objeto8 = resultado8.next();
            objeto8.setRegiaoEstacaoClimatica("Região Nordeste");
            db.store(objeto8);
        }

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 8");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 9
    private static void Update9(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<FavorabilidadesFas> resultado9 = db.queryByExample(new FavorabilidadesFas(3));
        String vetorID3 = "[(V1, [0.9]), (V2, [1.1]), (V3, [1.2]), (V4, [1.3]), (V5, [1.4]), (V6, [1.5]), "
                + "(V7, [1.6]), (S, [3.5]), (P_V1, [0.15]), (P_V2, [0.15]), (P_V3, [0.15]), "
                + "(P_V4, [0.15]), (P_V5, [0.15]), (P_V6, [0.15]), (P_V7, [0.15])]";
        if (!resultado9.isEmpty()) {
            FavorabilidadesFas objeto9 = resultado9.next();
            objeto9.setVetorFavorabilidade(vetorID3);
            db.store(objeto9);
        }
        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 9");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 10
    private static void Update10(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<FavorabilidadesFas> resultado10 = db.queryByExample(new FavorabilidadesFas(6));
        String vetorID6 = "[(V1, [1.0]), (V2, [0.9]), (V3, [1.3]), (V4, [1.2]), (V5, [1.1]), (V6, [1.4]), "
                + "(V7, [1.7]), (S, [3.2]), (P_V1, [0.14]), (P_V2, [0.14]), (P_V3, [0.14]), "
                + "(P_V4, [0.14]), (P_V5, [0.14]), (P_V6, [0.14]), (P_V7, [0.14])]";
        if (!resultado10.isEmpty()) {
            FavorabilidadesFas objeto10 = resultado10.next();
            objeto10.setVetorFavorabilidade(vetorID6);
            db.store(objeto10);
        }
        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 10");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 11
    private static void Update11(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<FavorabilidadesFas> resultado11 = db.queryByExample(new FavorabilidadesFas(9));
        String vetorID9 = "[(V1, [1.2]), (V2, [1.0]), (V3, [0.8]), (V4, [1.1]), (V5, [1.3]), (V6, [1.5]), "
                + "(V7, [1.4]), (S, [3.6]), (P_V1, [0.16]), (P_V2, [0.16]), (P_V3, [0.16]), "
                + "(P_V4, [0.16]), (P_V5, [0.16]), (P_V6, [0.16]), (P_V7, [0.16])]";
        if (!resultado11.isEmpty()) {
            FavorabilidadesFas objeto11 = resultado11.next();
            objeto11.setVetorFavorabilidade(vetorID9);
            db.store(objeto11);
        }
        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 11");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 12
    private static void Update12(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<FavorabilidadesFas> resultado12 = db.queryByExample(new FavorabilidadesFas(12));
        String vetorID12 = "[(V1, [1.1]), (V2, [1.2]), (V3, [1.3]), (V4, [0.9]), (V5, [1.4]), (V6, [1.6]), "
                + "(V7, [1.8]), (S, [3.8]), (P_V1, [0.17]), (P_V2, [0.17]), (P_V3, [0.17]), "
                + "(P_V4, [0.17]), (P_V5, [0.17]), (P_V6, [0.17]), (P_V7, [0.17])]";
        if (!resultado12.isEmpty()) {
            FavorabilidadesFas objeto12 = resultado12.next();
            objeto12.setVetorFavorabilidade(vetorID12);
            db.store(objeto12);
        }
        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 12");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 13
    private static void Update13(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<Fungicidas> resultado13 = db.queryByExample(new Fungicidas(1));
        Fungicidas objeto13 = resultado13.next();
        objeto13.setTratamento("REX (difenoconazol + ciproconazol)");
        db.store(objeto13);

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 13");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 14
    private static void Update14(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<Fungicidas> resultado14 = db.queryByExample(new Fungicidas(2));
        Fungicidas objeto14 = resultado14.next();
        objeto14.setTratamento("HEX (picoxistrobina + tebuconazol)");
        db.store(objeto14);

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 14");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 15
    private static void Update15(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<Fungicidas> resultado15 = db.queryByExample(new Fungicidas(3));
        Fungicidas objeto15 = resultado15.next();
        objeto15.setTratamento("MAX (trifloxistrobina + tebuconazol)");
        db.store(objeto15);

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 15");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    // Update 16
    private static void Update16(ObjectContainer db, List<Object> textDurationList) {
        Instant inicioAlteracao = Instant.now();

        ObjectSet<Fungicidas> resultado16 = db.queryByExample(new Fungicidas(4));
        Fungicidas objeto16 = resultado16.next();
        objeto16.setTratamento("ACT (flutriafol + prothioconazole)");
        db.store(objeto16);

        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 16");
        textDurationList.add(Duration.between(inicioAlteracao, fimAlteracao).toMillis());
    }

    public static void Update17(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        Query query = db.query();
        query.constrain(FavorabilidadesFas.class);
        ObjectSet<FavorabilidadesFas> results = query.execute();

        for (FavorabilidadesFas fav : results) {
            if ("Favorabilidade Alta".equals(fav.getResultadoFavorabilidade())) {
                fav.setResultadoFavorabilidade("Favorabilidade Média");
            } else if ("Favorabilidade Média".equals(fav.getResultadoFavorabilidade())) {
                fav.setResultadoFavorabilidade("Favorabilidade Alta");
            }
            db.store(fav);
        }
        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 17");
        textDurationList.add(Duration.between(inicio, fimAlteracao).toMillis());
    }

    public static void Update18(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        Query query = db.query();
        query.constrain(DadosClimaticos.class);
        query.descend("localEstacaoClimatica").constrain("Estacao Poxoreu");
        ObjectSet<DadosClimaticos> results = query.execute();

        for (DadosClimaticos dados : results) {
            dados.setLocalEstacaoClimatica("Estacao Rondonopolis");
            db.store(dados);
        }
        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 18");
        textDurationList.add(Duration.between(inicio, fimAlteracao).toMillis());
    }

    public static void Update19(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        Query query = db.query();
        query.constrain(DadosClimaticos.class);
        ObjectSet<DadosClimaticos> results = query.execute();

        for (DadosClimaticos dados : results) {
            if (dados.getPeriodoMedicao().contains("safra")) {
                dados.setPeriodoMedicao(dados.getPeriodoMedicao().replace("safra", "sifra"));
                db.store(dados);
            }
        }
        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 19");
        textDurationList.add(Duration.between(inicio, fimAlteracao).toMillis());
    }

    public static void Update20(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        Query query = db.query();
        query.constrain(ImagemClimaFavorab.class);
        ObjectSet<ImagemClimaFavorab> results = query.execute();

        for (ImagemClimaFavorab img : results) {
            if ("Favorabilidade Alta".equals(img.getDescFavorab())) {
                img.setDescFavorab("Favorabilidade Média");
            } else if ("Favorabilidade Média".equals(img.getDescFavorab())) {
                img.setDescFavorab("Favorabilidade Alta");
            }
            db.store(img);
        }
        Instant fimAlteracao = Instant.now();
        textDurationList.add("Tempo de Update 20");
        textDurationList.add(Duration.between(inicio, fimAlteracao).toMillis());
    }

    public static void Exclusao1(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos dentro do intervalo de IDs
        Query query = db.query();
        query.constrain(BancoImagens.class); // Filtra objetos do tipo BancoImagens
        query.descend("id").constrain(10).greater().and(
                query.descend("id").constrain(20).smaller().equal()
        );

        // Obtém os resultados da consulta
        ObjectSet<BancoImagens> resultados = query.execute();

        // Itera pelos resultados e os remove do banco
        for (BancoImagens bancoImagem : resultados) {
            System.out.println("Deletando: " + bancoImagem);
            db.delete(bancoImagem);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 1");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao2(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos cuja descrição começa com "DSC_01"
        Query query = db.query();
        query.constrain(BancoImagens.class); // Filtra objetos da classe BancoImagens
        query.descend("descricaoImgOriginal").constrain("DSC_01").startsWith(true);

        // Obtém os resultados da consulta
        ObjectSet<BancoImagens> resultados = query.execute();

        // Itera pelos resultados e os remove do banco
        for (BancoImagens bancoImagem : resultados) {
            System.out.println("Deletando: " + bancoImagem.getDescricaoImgOriginal());
            db.delete(bancoImagem);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 2");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao3(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos dentro do intervalo de IDs
        Query query = db.query();
        query.constrain(DadosClimaticos.class); // Filtra objetos do tipo BancoImagens
        query.descend("id").constrain(10).greater().and(
                query.descend("id").constrain(20).smaller().equal()
        );

        // Obtém os resultados da consulta
        ObjectSet<DadosClimaticos> resultados = query.execute();

        // Itera pelos resultados e os remove do banco
        for (DadosClimaticos dadosClimaticos : resultados) {
            System.out.println("Deletando: " + dadosClimaticos);
            db.delete(dadosClimaticos);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 3");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao4(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Criação da consulta inicial para filtrar por localEstacaoClimatica
        Query query = db.query();
        query.constrain(DadosClimaticos.class);
        query.descend("localEstacaoClimatica").constrain("Estação Poxoréu");

        // Obter os resultados preliminares
        ObjectSet<DadosClimaticos> resultados = query.execute();

        // Filtrar e deletar no código
        for (DadosClimaticos dados : resultados) {
            LocalDate data = dados.getDataMedicao();
            if (data != null && data.getYear() == 2000 && data.getMonthValue() == 1 && data.getDayOfMonth() <= 9) {
                System.out.println("Deletando: " + dados);
                db.delete(dados);
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 4");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao5(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos que atendem às condições
        Query query = db.query();
        query.constrain(DadosClimaticos.class); // Filtra objetos do tipo DadosClimaticos
        query.descend("precipitacao").constrain(20).smaller();
        query.descend("temperaturaMax").constrain(30).smaller();

        // Executa a consulta e obtém os resultados
        ObjectSet<DadosClimaticos> resultados = query.execute();

        // Itera pelos resultados e os remove do banco
        for (DadosClimaticos dadosClimaticos : resultados) {
            System.out.println("Deletando: " + dadosClimaticos);
            db.delete(dadosClimaticos);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 5");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao6(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos com temperaturaMedCompensada entre 25 e 27
        Query query = db.query();
        query.constrain(DadosClimaticos.class); // Filtra objetos do tipo DadosClimaticos
        query.descend("temperaturaMedCompensada").constrain(25).greater().and(
                query.descend("temperaturaMedCompensada").constrain(27).smaller()
        );

        // Executa a consulta
        ObjectSet<DadosClimaticos> resultados = query.execute();

        // Itera pelos resultados e os remove
        for (DadosClimaticos dadosClimaticos : resultados) {
            System.out.println("Deletando: " + dadosClimaticos);
            db.delete(dadosClimaticos);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 6");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao7(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Consultar todos os objetos FavorabilidadesFas
        List<FavorabilidadesFas> resultados = db.query(FavorabilidadesFas.class);

        for (FavorabilidadesFas favorabilidade : resultados) {
            LocalDate data = favorabilidade.getJanelaTempoFinal();
            if (data != null && data.getYear() == 2000 && data.getMonthValue() <= 9) {
                System.out.println("Deletando: " + favorabilidade);
                db.delete(favorabilidade);
            }
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 7");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao8(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos FavorabilidadesFas que contêm 'Media' em vetorFavorabilidade
        Query query = db.query();
        query.constrain(FavorabilidadesFas.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("vetorFavorabilidade").constrain("Baixa").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<FavorabilidadesFas> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (FavorabilidadesFas favorabilidade : resultados) {
            System.out.println("Deletando: " + favorabilidade);
            db.delete(favorabilidade);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 8");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao9(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos FavorabilidadesFas que contêm 'Media' em vetorFavorabilidade
        Query query = db.query();
        query.constrain(FavorabilidadesFas.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("vetorFavorabilidade").constrain("Alta").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<FavorabilidadesFas> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (FavorabilidadesFas favorabilidade : resultados) {
            System.out.println("Deletando: " + favorabilidade);
            db.delete(favorabilidade);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 9");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao10(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Criando uma consulta para buscar objetos de Fungicidas com severidade < 28
        Query query = db.query();
        query.constrain(Fungicidas.class);  // Restringe a classe Fungicidas
        query.descend("severidade").constrain(28).smaller();  // Verifica severidade < 28

        // Obtendo os resultados da consulta
        ObjectSet<Fungicidas> resultados = query.execute();

        // Iterando sobre os resultados e deletando os objetos
        for (Fungicidas fungicida : resultados) {
            System.out.println("Deletando: " + fungicida);
            db.delete(fungicida);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 10");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao11(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos FavorabilidadesFas que contêm 'Media' em vetorFavorabilidade
        Query query = db.query();
        query.constrain(ImagemClimaFavorab.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("descFavorab").constrain("Alta").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<ImagemClimaFavorab> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (ImagemClimaFavorab imagemClima : resultados) {
            System.out.println("Deletando: " + imagemClima);
            db.delete(imagemClima);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 11");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao12(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos FavorabilidadesFas que contêm 'Media' em vetorFavorabilidade
        Query query = db.query();
        query.constrain(ImagensSegmentadas.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("classeCor").constrain("verde").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<ImagensSegmentadas> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (ImagensSegmentadas imagemSeg : resultados) {
            System.out.println("Deletando: " + imagemSeg);
            db.delete(imagemSeg);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 12");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao13(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos FavorabilidadesFas que contêm 'Media' em vetorFavorabilidade
        Query query = db.query();
        query.constrain(RotuloSegmentados.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("classeCor").constrain("verde").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<RotuloSegmentados> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (RotuloSegmentados rotuloSeg : resultados) {
            System.out.println("Deletando: " + rotuloSeg);
            db.delete(rotuloSeg);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 13");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao14(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos FavorabilidadesFas que contêm 'Media' em vetorFavorabilidade
        Query query = db.query();
        query.constrain(RotuloSegmentados.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("classeCor").constrain("amarelo").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<RotuloSegmentados> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (RotuloSegmentados rotuloSeg : resultados) {
            System.out.println("Deletando: " + rotuloSeg);
            db.delete(rotuloSeg);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 14");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao15(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar objetos de Segmentacao
        Query query = db.query();
        query.constrain(Segmentacao.class); // Filtra por Segmentacao
        query.descend("coordenadasCalcJanela").constrain("19").contains().or(
                query.descend("coordenadasCalcJanela").constrain("16").contains()
        );

        // Executa a consulta e obtém os resultados
        ObjectSet<Segmentacao> resultados = query.execute();

        // Itera e deleta os objetos encontrados
        while (resultados.hasNext()) {
            Segmentacao segmento = resultados.next();
            db.delete(segmento);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 15");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao16(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        Query query = db.query();
        query.constrain(RotuloSegmentados.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("dadosSementes").constrain("10%").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<Sementes> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (Sementes semente : resultados) {
            System.out.println("Deletando: " + semente);
            db.delete(semente);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 16");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao17(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
// Cria uma consulta para buscar os objetos FavorabilidadesFas que contêm 'Media' em vetorFavorabilidade
        Query query = db.query();
        query.constrain(Sementes.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("descricaoCorSemente").constrain("marrom").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<Sementes> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (Sementes semente : resultados) {
            System.out.println("Deletando: " + semente);
            db.delete(semente);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 17");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao18(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        Query query = db.query();
        query.constrain(Sementes.class); // Filtra objetos da classe FavorabilidadesFas
        query.descend("descricaoCorSemente").constrain("amarela").contains(); // Pesquisa por "Media" em qualquer posição

        // Obtém os resultados da consulta
        ObjectSet<Sementes> resultados = query.execute();

        // Itera pelos resultados e deleta os objetos
        for (Sementes semente : resultados) {
            System.out.println("Deletando: " + semente);
            db.delete(semente);
        }
    }

    public static void Exclusao19(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos com temperaturaMedCompensada entre 25 e 27
        Query query = db.query();
        query.constrain(TabVerdFavorabilidade.class); // Filtra objetos do tipo DadosClimaticos
        query.descend("pV1").constrain(0.25).greater().and(
                query.descend("pV1").constrain(0.1).smaller()
        );

        // Executa a consulta
        ObjectSet<TabVerdFavorabilidade> resultados = query.execute();

        // Itera pelos resultados e os remove
        for (TabVerdFavorabilidade tabVerd : resultados) {
            System.out.println("Deletando: " + tabVerd);
            db.delete(tabVerd);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 19");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

    public static void Exclusao20(ObjectContainer db, List<Object> textDurationList) {
        Instant inicio = Instant.now(); // Cronômetragem do tempo de Execução (início)
        // Cria uma consulta para buscar os objetos de Classificacoes onde o campo relatorioClassificacao contém "DSC_01"
        Query query = db.query();
        query.constrain(Classificacoes.class); // Filtra objetos do tipo Classificacoes
        query.descend("relatorioClassificacao").constrain("DSC_01").like();

        // Executa a consulta e obtém os resultados
        ObjectSet<Classificacoes> resultados = query.execute();

        // Itera pelos resultados e os remove do banco
        while (resultados.hasNext()) {
            Classificacoes classificacao = resultados.next();
            System.out.println("Deletando: " + classificacao);
            db.delete(classificacao);
        }
        Instant fim = Instant.now(); //Cronômetragem do tempo de Execução (fim)
        textDurationList.add("Tempo de execução Exclusão 20");// Insere um texto de identificação à lista
        textDurationList.add((Duration.between(inicio, fim).toMillis())); // Calcula a duração insere à lista
    }

}
