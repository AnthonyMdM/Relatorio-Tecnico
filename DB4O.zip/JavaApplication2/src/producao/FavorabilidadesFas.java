/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.time.LocalDate;
/**
 *
 * @author antho
 */
public class FavorabilidadesFas {
    private Integer id;
    private static int contadorId = 0;
    private String resultadoFavorabilidade; // resultado_favorabilidade (character varying)
    private String vetorFavorabilidade; // vetor_favorabilidade (character varying)
    private java.time.LocalDate janelaTempoInicial; // janela_tempo_inicial (date)
    private java.time.LocalDate janelaTempoFinal; // janela_tempo_final (date)
    private String abordagemFusaoDados; // abordagem_fusao_dados (character varying)
    private Integer v1; // v1 (integer, pode ser null)
    private Integer v2; // v2 (integer, pode ser null)
    private Integer v3; // v3 (integer, pode ser null)
    private Integer v4; // v4 (integer, pode ser null)
    private Integer v5; // v5 (integer, pode ser null)
    private Integer v6; // v6 (integer, pode ser null)
    private Integer v7; // v7 (integer, pode ser null)

    // Construtor padrão
    public FavorabilidadesFas() {
    }
    
    public FavorabilidadesFas(Integer id){
       this.id = id; 
    }
    // Construtor com parâmetros

    public FavorabilidadesFas(Integer id, String resultadoFavorabilidade, String vetorFavorabilidade, LocalDate janelaTempoInicial, LocalDate janelaTempoFinal, String abordagemFusaoDados, Integer v1, Integer v2, Integer v3, Integer v4, Integer v5, Integer v6, Integer v7) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.resultadoFavorabilidade = resultadoFavorabilidade;
        this.vetorFavorabilidade = vetorFavorabilidade;
        this.janelaTempoInicial = janelaTempoInicial;
        this.janelaTempoFinal = janelaTempoFinal;
        this.abordagemFusaoDados = abordagemFusaoDados;
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
        this.v4 = v4;
        this.v5 = v5;
        this.v6 = v6;
        this.v7 = v7;
    }
    
    // Getters e Setters para encapsulamento
    public int getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public String getResultadoFavorabilidade() {
        return resultadoFavorabilidade;
    }

    public void setResultadoFavorabilidade(String resultadoFavorabilidade) {
        this.resultadoFavorabilidade = resultadoFavorabilidade;
    }

    public String getVetorFavorabilidade() {
        return vetorFavorabilidade;
    }

    public void setVetorFavorabilidade(String vetorFavorabilidade) {
        this.vetorFavorabilidade = vetorFavorabilidade;
    }

    public java.time.LocalDate getJanelaTempoInicial() {
        return janelaTempoInicial;
    }

    public void setJanelaTempoInicial(java.time.LocalDate janelaTempoInicial) {
        this.janelaTempoInicial = janelaTempoInicial;
    }

    public java.time.LocalDate getJanelaTempoFinal() {
        return janelaTempoFinal;
    }

    public void setJanelaTempoFinal(LocalDate janelaTempoFinal) {
        this.janelaTempoFinal = janelaTempoFinal;
    }

    public String getAbordagemFusaoDados() {
        return abordagemFusaoDados;
    }

    public void setAbordagemFusaoDados(String abordagemFusaoDados) {
        this.abordagemFusaoDados = abordagemFusaoDados;
    }

    public Integer getV1() {
        return v1;
    }

    public void setV1(Integer v1) {
        this.v1 = v1;
    }

    public Integer getV2() {
        return v2;
    }

    public void setV2(Integer v2) {
        this.v2 = v2;
    }

    public Integer getV3() {
        return v3;
    }

    public void setV3(Integer v3) {
        this.v3 = v3;
    }

    public Integer getV4() {
        return v4;
    }

    public void setV4(Integer v4) {
        this.v4 = v4;
    }

    public Integer getV5() {
        return v5;
    }

    public void setV5(Integer v5) {
        this.v5 = v5;
    }

    public Integer getV6() {
        return v6;
    }

    public void setV6(Integer v6) {
        this.v6 = v6;
    }

    public Integer getV7() {
        return v7;
    }

    public void setV7(Integer v7) {
        this.v7 = v7;
    }
    
    public void adicionarAoBancoImagens(int bancoId, ObjectContainer db) {
        BancoImagens exemploBanco = new BancoImagens();
        exemploBanco.setId(bancoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<BancoImagens> resultado = db.queryByExample(exemploBanco);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            BancoImagens projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarFavorabilidadesFas(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + bancoId);
        } else {
            System.out.println("Projeto com ID " + bancoId + " não encontrado.");
        }
    }
    @Override
    public String toString() {
        return "FavorabilidadesFas{" + "id=" + id + ", resultadoFavorabilidade=" + resultadoFavorabilidade + ", vetorFavorabilidade=" + vetorFavorabilidade + ", janelaTempoInicial=" + janelaTempoInicial + ", janelaTempoFinal=" + janelaTempoFinal + ", abordagemFusaoDados=" + abordagemFusaoDados + ", v1=" + v1 + ", v2=" + v2 + ", v3=" + v3 + ", v4=" + v4 + ", v5=" + v5 + ", v6=" + v6 + ", v7=" + v7 + '}';
    }

}
