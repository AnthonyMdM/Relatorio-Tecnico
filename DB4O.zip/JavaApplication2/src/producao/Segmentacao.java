/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author antho
 */
public class Segmentacao {
    private Integer id;
    private static int contadorId = 0; 
    private String dataHoraProjeto; // data_hora_projeto (character varying)
    private String coordenadasSementeCentral; // coordenadas_semente_central (character varying)
    private String coordenadasCalcJanela; // coordenadas_calc_janela (character varying)
    private int totalPixelsJanela; // total_pixels_janela (integer)
    private int totalSementesCalculadas; // total_sementes_calculadas (integer)
    private double erroEstatisticoCalculado; // erro_estatistico_calculado (double precision)
    private String operacaoProjeto; // operacao_projeto (character varying)
    private double desvioPadrao; // desvio_padrao (double precision)
    private int limiar1Segmentacao;
    private int limiar2Segmentacao;
    private String faixaLimiares;
    private double varianciaSegmentacao;
    private String coordJanelaFinalObjInter;
    private String sementesCalculadasJanela;
    private String relatorioColetaAutSemente;
    private String relatorioDadosEstatisticos;
    private List<RotuloSegmentados> rotuloSegmentadosList = new ArrayList<>();
    // Construtor padrão
    public Segmentacao() {
    }

    public Segmentacao(Integer id, String dataHoraProjeto, String coordenadasSementeCentral,
            String coordenadasCalcJanela, int totalPixelsJanela, int totalSementesCalculadas,
            double erroEstatisticoCalculado, String operacaoProjeto, double desvioPadrao, int limiar1Segmentacao,
            int limiar2Segmentacao, String faixaLimiares, double varianciaSegmentacao, String coordJanelaFinalObjInter,
            String sementesCalculadasJanela, String relatorioColetaAutSemente, String relatorioDadosEstatisticos) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.dataHoraProjeto = dataHoraProjeto;
        this.coordenadasSementeCentral = coordenadasSementeCentral;
        this.coordenadasCalcJanela = coordenadasCalcJanela;
        this.totalPixelsJanela = totalPixelsJanela;
        this.totalSementesCalculadas = totalSementesCalculadas;
        this.erroEstatisticoCalculado = erroEstatisticoCalculado;
        this.operacaoProjeto = operacaoProjeto;
        this.desvioPadrao = desvioPadrao;
        this.limiar1Segmentacao = limiar1Segmentacao;
        this.limiar2Segmentacao = limiar2Segmentacao;
        this.faixaLimiares = faixaLimiares;
        this.varianciaSegmentacao = varianciaSegmentacao;
        this.coordJanelaFinalObjInter = coordJanelaFinalObjInter;
        this.sementesCalculadasJanela = sementesCalculadasJanela;
        this.relatorioColetaAutSemente = relatorioColetaAutSemente;
        this.relatorioDadosEstatisticos = relatorioDadosEstatisticos;
    }

    public void adicionarRotuloSegmentados(RotuloSegmentados rotulo) {
        rotuloSegmentadosList.add(rotulo);
    }
    
    public void getIdBancoRotuloSegmentados() {
        rotuloSegmentadosList.forEach(System.out::println);
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataHoraProjeto() {
        return dataHoraProjeto;
    }

    public void setDataHoraProjeto(String dataHoraProjeto) {
        this.dataHoraProjeto = dataHoraProjeto;
    }

    public String getCoordenadasSementeCentral() {
        return coordenadasSementeCentral;
    }

    public void setCoordenadasSementeCentral(String coordenadasSementeCentral) {
        this.coordenadasSementeCentral = coordenadasSementeCentral;
    }

    public String getCoordenadasCalcJanela() {
        return coordenadasCalcJanela;
    }

    public void setCoordenadasCalcJanela(String coordenadasCalcJanela) {
        this.coordenadasCalcJanela = coordenadasCalcJanela;
    }

    public int getTotalPixelsJanela() {
        return totalPixelsJanela;
    }

    public void setTotalPixelsJanela(int totalPixelsJanela) {
        this.totalPixelsJanela = totalPixelsJanela;
    }

    public int getTotalSementesCalculadas() {
        return totalSementesCalculadas;
    }

    public void setTotalSementesCalculadas(int totalSementesCalculadas) {
        this.totalSementesCalculadas = totalSementesCalculadas;
    }

    public double getErroEstatisticoCalculado() {
        return erroEstatisticoCalculado;
    }

    public void setErroEstatisticoCalculado(double erroEstatisticoCalculado) {
        this.erroEstatisticoCalculado = erroEstatisticoCalculado;
    }

    public String getOperacaoProjeto() {
        return operacaoProjeto;
    }

    public void setOperacaoProjeto(String operacaoProjeto) {
        this.operacaoProjeto = operacaoProjeto;
    }

    public double getDesvioPadrao() {
        return desvioPadrao;
    }

    public void setDesvioPadrao(double desvioPadrao) {
        this.desvioPadrao = desvioPadrao;
    }

    public int getLimiar1Segmentacao() {
        return limiar1Segmentacao;
    }

    public void setLimiar1Segmentacao(int limiar1Segmentacao) {
        this.limiar1Segmentacao = limiar1Segmentacao;
    }

    public int getLimiar2Segmentacao() {
        return limiar2Segmentacao;
    }

    public void setLimiar2Segmentacao(int limiar2Segmentacao) {
        this.limiar2Segmentacao = limiar2Segmentacao;
    }

    public String getFaixaLimiares() {
        return faixaLimiares;
    }

    public void setFaixaLimiares(String faixaLimiares) {
        this.faixaLimiares = faixaLimiares;
    }

    public double getVarianciaSegmentacao() {
        return varianciaSegmentacao;
    }

    public void setVarianciaSegmentacao(double varianciaSegmentacao) {
        this.varianciaSegmentacao = varianciaSegmentacao;
    }

    public String getCoordJanelaFinalObjInter() {
        return coordJanelaFinalObjInter;
    }

    public void setCoordJanelaFinalObjInter(String coordJanelaFinalObjInter) {
        this.coordJanelaFinalObjInter = coordJanelaFinalObjInter;
    }

    public String getSementesCalculadasJanela() {
        return sementesCalculadasJanela;
    }

    public void setSementesCalculadasJanela(String sementesCalculadasJanela) {
        this.sementesCalculadasJanela = sementesCalculadasJanela;
    }

    public String getRelatorioColetaAutSemente() {
        return relatorioColetaAutSemente;
    }

    public void setRelatorioColetaAutSemente(String relatorioColetaAutSemente) {
        this.relatorioColetaAutSemente = relatorioColetaAutSemente;
    }

    public String getRelatorioDadosEstatisticos() {
        return relatorioDadosEstatisticos;
    }

    public void setRelatorioDadosEstatisticos(String relatorioDadosEstatisticos) {
        this.relatorioDadosEstatisticos = relatorioDadosEstatisticos;
    }
    
    public void adicionarAoProjeto(int projetoId, ObjectContainer db) {
        Projetos exemploProjeto = new Projetos();
        exemploProjeto.setId(projetoId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Projetos> resultado = db.queryByExample(exemploProjeto);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Projetos projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarSegmentacao(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + projetoId);
        } else {
            System.out.println("Projeto com ID " + projetoId + " não encontrado.");
        }
    }
    public void adicionarAsImagensSegmentadas(int imagensSegmentadasId, ObjectContainer db) {
        ImagensSegmentadas exemploImagensSegmentadas = new ImagensSegmentadas();
        exemploImagensSegmentadas.setId(imagensSegmentadasId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<ImagensSegmentadas> resultado = db.queryByExample(exemploImagensSegmentadas);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            ImagensSegmentadas projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarSegmentacao(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + imagensSegmentadasId);
        } else {
            System.out.println("Projeto com ID " + imagensSegmentadasId + " não encontrado.");
        }
    }
    
    public void adicionarAsSementes(int sementesId, ObjectContainer db) {
        Sementes exemploSementes = new Sementes();
        exemploSementes.setId(sementesId);

        // Busca o Projeto pelo ID fornecido
        ObjectSet<Sementes> resultado = db.queryByExample(exemploSementes);
        
        if (resultado.hasNext()) {
            // Associa o Projeto encontrado ao BancoImagens
            Sementes projetoEncontrado = resultado.next();
            projetoEncontrado.adicionarSegmentacao(this);  // Adiciona o BancoImagens no Projeto
            db.store(projetoEncontrado);  // Salva o Projeto atualizado no DB4O
            
            System.out.println("BancoImagens adicionado ao Projeto com ID: " + sementesId);
        } else {
            System.out.println("Projeto com ID " + sementesId + " não encontrado.");
        }
    }
    @Override
    public String toString() {
        return "Segmentacao{" + "id=" + id + ", dataHoraProjeto=" + dataHoraProjeto + ", coordenadasSementeCentral=" + coordenadasSementeCentral + ", coordenadasCalcJanela=" + coordenadasCalcJanela + ", totalPixelsJanela=" + totalPixelsJanela + ", totalSementesCalculadas=" + totalSementesCalculadas + ", erroEstatisticoCalculado=" + erroEstatisticoCalculado + ", operacaoProjeto=" + operacaoProjeto + ", desvioPadrao=" + desvioPadrao + ", limiar1Segmentacao=" + limiar1Segmentacao + ", limiar2Segmentacao=" + limiar2Segmentacao + ", faixaLimiares=" + faixaLimiares + ", varianciaSegmentacao=" + varianciaSegmentacao + ", coordJanelaFinalObjInter=" + coordJanelaFinalObjInter + ", sementesCalculadasJanela=" + sementesCalculadasJanela + ", relatorioColetaAutSemente=" + relatorioColetaAutSemente + ", relatorioDadosEstatisticos=" + relatorioDadosEstatisticos + ", rotuloSegmentadosList=" + rotuloSegmentadosList + '}';
    }


}