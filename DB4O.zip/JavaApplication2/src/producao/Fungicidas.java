/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author antho
 */
public class Fungicidas {
    private static int contadorId = 0;
    private Integer id;
    private String tratamento; // tratamento (character varying)
    private String dosagem1; // dosagem_1 (character varying)
    private String dosagem2; // dosagem_2 (character varying)
    private double severidade; // severidade (double precision)
    private double porcentagemControle; // porcentagem_controle (double precision)
    private Integer produtividade; // produtividade (integer, pode ser null)
    private List<RecomendacoesFungicidas> recomendacoesFungicidasList = new ArrayList<>();

    // Construtor padrão
    public Fungicidas() {
    }
    
    public Fungicidas(Integer id){
       this.id = id; 
    }
            
    // Construtor com parâmetros
    public Fungicidas(Integer id, String tratamento, String dosagem1, String dosagem2, 
                     double severidade, double porcentagemControle, Integer produtividade) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.tratamento = tratamento;
        this.dosagem1 = dosagem1;
        this.dosagem2 = dosagem2;
        this.severidade = severidade;
        this.porcentagemControle = porcentagemControle;
        this.produtividade = produtividade;
    }

    // Getters e Setters para encapsulamento
    
    public void adicionarRecomendacoesFungicidas(RecomendacoesFungicidas recomendacoes) {
        recomendacoesFungicidasList.add(recomendacoes);
    }
    
    public void getRecomendacoesFungicidas() {
        recomendacoesFungicidasList.forEach(System.out::println);
    }

    public int getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public String getTratamento() {
        return tratamento;
    }

    public void setTratamento(String tratamento) {
        this.tratamento = tratamento;
    }

    public String getDosagem1() {
        return dosagem1;
    }

    public void setDosagem1(String dosagem1) {
        this.dosagem1 = dosagem1;
    }

    public String getDosagem2() {
        return dosagem2;
    }

    public void setDosagem2(String dosagem2) {
        this.dosagem2 = dosagem2;
    }

    public double getSeveridade() {
        return severidade;
    }

    public void setSeveridade(double severidade) {
        this.severidade = severidade;
    }

    public double getPorcentagemControle() {
        return porcentagemControle;
    }

    public void setPorcentagemControle(double porcentagemControle) {
        this.porcentagemControle = porcentagemControle;
    }

    public Integer getProdutividade() {
        return produtividade;
    }

    public void setProdutividade(Integer produtividade) {
        this.produtividade = produtividade;
    }

    @Override
    public String toString() {
        return "Fungicidas{" + "id=" + id + ", tratamento=" + tratamento + ", dosagem1=" + dosagem1 + ", dosagem2=" + dosagem2 + ", severidade=" + severidade + ", porcentagemControle=" + porcentagemControle + ", produtividade=" + produtividade + ", recomendacoesFungicidasList=" + recomendacoesFungicidasList + '}';
    }

}
