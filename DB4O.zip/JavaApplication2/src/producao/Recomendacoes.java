/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package producao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author antho
 */
public class Recomendacoes {
    // Atributos privados da classe
    private static int contadorId = 0;
    private Integer id;
    private String recomendacaoFavorabBaixa; // recomendacao_favorab_baixa (text)
    private String recomendacaoFavorabMedia; // recomendacao_favorab_media (text)
    private String recomendacaoFavorabAlta; // recomendacao_favorab_alta (text)
    private List<RecomendacoesFungicidas> recomendacoesFungicidasList = new ArrayList<>();

    // Construtor padrão
    public Recomendacoes() {
    }

    // Construtor com parâmetros
    public Recomendacoes(Integer id, String recomendacaoFavorabBaixa, String recomendacaoFavorabMedia, 
                        String recomendacaoFavorabAlta) {
        if(id == null)
            this.id = ++contadorId; // Gera um novo ID automaticamente
        else
            this.id = id;
        this.recomendacaoFavorabBaixa = recomendacaoFavorabBaixa;
        this.recomendacaoFavorabMedia = recomendacaoFavorabMedia;
        this.recomendacaoFavorabAlta = recomendacaoFavorabAlta;
    }

    // Getters e Setters para encapsulamento
    
    public void adicionarRecomendacoesFungicidas(RecomendacoesFungicidas recomendacoes) {
        recomendacoesFungicidasList.add(recomendacoes);
    }
    
    public void getRecomendacoesFungicidas() {
        recomendacoesFungicidasList.forEach(System.out::println);
    }

    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }

    public String getRecomendacaoFavorabBaixa() {
        return recomendacaoFavorabBaixa;
    }

    public void setRecomendacaoFavorabBaixa(String recomendacaoFavorabBaixa) {
        this.recomendacaoFavorabBaixa = recomendacaoFavorabBaixa;
    }

    public String getRecomendacaoFavorabMedia() {
        return recomendacaoFavorabMedia;
    }

    public void setRecomendacaoFavorabMedia(String recomendacaoFavorabMedia) {
        this.recomendacaoFavorabMedia = recomendacaoFavorabMedia;
    }

    public String getRecomendacaoFavorabAlta() {
        return recomendacaoFavorabAlta;
    }

    public void setRecomendacaoFavorabAlta(String recomendacaoFavorabAlta) {
        this.recomendacaoFavorabAlta = recomendacaoFavorabAlta;
    }

    @Override
    public String toString() {
        return "Recomendacoes{" + "id=" + id + ", recomendacaoFavorabBaixa=" + recomendacaoFavorabBaixa + ", recomendacaoFavorabMedia=" + recomendacaoFavorabMedia + ", recomendacaoFavorabAlta=" + recomendacaoFavorabAlta + ", recomendacoesFungicidasList=" + recomendacoesFungicidasList + '}';
    }

}
